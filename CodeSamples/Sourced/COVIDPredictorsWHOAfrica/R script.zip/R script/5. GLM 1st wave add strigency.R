library(splines)
library(Epi)
library(glmnet)
library(WriteXLS)
library(tidyverse)
library(reshape2)
library(mgcv)
library(MASS)
require(MESS)
library(dplyr)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##load data_for_analysing_mortality_1stWAVE updated.RData#######
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
load("./R data/data_for_analysing_mortality_1stWAVE updated.RData")

## remove outliers or countries with missing predictors
data_analysis_fixed2 <- data_analysis_fixed[-which(data_analysis_fixed$countryterritoryCode=="ERI"|
                                                      data_analysis_fixed$countryterritoryCode=="BDI"|
                                                      data_analysis_fixed$countryterritoryCode=="TZA"|
                                                      data_analysis_fixed$Hiv==999),]


library(lme4)
library(AICcmodavg)

# Re-load Best model ####
po1 <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) + 
               urban_pop + airport_seats + Hiv, data_analysis_fixed2,family = poisson) 

summary(po1)
AIC(po1) ##  623.2754
AICc(po1) ##624.9421

multi_AIC <- data.frame(coef(summary(po1)))
multi_AIC$var <- rownames(multi_AIC)
multi_AIC <- multi_AIC[,-3]
names(multi_AIC) <- c("Coefficient","SD","p","var") 

multi_AIC <- multi_AIC[!grepl("(Intercept)", multi_AIC$var),]

multi_AIC$RR <- exp(multi_AIC$Coefficient)
multi_AIC$Lower <- exp(multi_AIC$Coefficient -1.96*multi_AIC$SD)
multi_AIC$Upper <- exp(multi_AIC$Coefficient +1.96*multi_AIC$SD)



## Extended Data Fig. 5 correlation matrix before adding strigency index#########

dat_cor <- data_analysis_fixed2[,c(11,17,22,35,36)] 
names(dat_cor) <- c("Urban population\n(% of total population)" ,
                    "Volume of international\nair travel",
                    'Prevalence of HIV, total\n(% of population ages 15-49)',
                    'AUC of stringency index',
                    'Stringency index when cumulative\ndeaths reached 0.1 per 100K population')


res <- cor(dat_cor, method = "spearman",use = "complete.obs")

library(corrplot)
library(Cairo)
cairo_pdf('./Results/Extended Data/Extended Data Fig. 5.pdf',width=12,height=8) #,family="Arial Unicode MS"
col <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD", "#4477AA"))
par(mar=c(0,0,0,0))
corrplot(res, method="color", col=col(200),  
         type="lower", order="original", 
         addCoef.col = "black", # Add coefficient of correlation
         tl.col="black", tl.srt=45, tl.offset=0.8,number.digits=3,#Text label color and rotation
         # hide correlation coefficient on the principal diagonal
         diag=FALSE,
         mar = c(0, 0, 0, 0))
dev.off()

## add AUC_all####
po_AUC_all <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) + 
               urban_pop + airport_seats + Hiv + str_auc_all, data_analysis_fixed2,family = poisson) 

summary(po_AUC_all) # 
AIC(po_AUC_all) #625.2498
AICc(po_AUC_all) #627.6498

multi_AIC_AUC_all <- data.frame(coef(summary(po_AUC_all)))
multi_AIC_AUC_all$var <- rownames(multi_AIC_AUC_all)
multi_AIC_AUC_all <- multi_AIC_AUC_all[,-3]
names(multi_AIC_AUC_all) <- c("Coefficient","SD","p","var") 

multi_AIC_AUC_all <- multi_AIC_AUC_all[!grepl("(Intercept)", multi_AIC_AUC_all$var),]

multi_AIC_AUC_all$RR <- exp(multi_AIC_AUC_all$Coefficient)
multi_AIC_AUC_all$Lower <- exp(multi_AIC_AUC_all$Coefficient -1.96*multi_AIC_AUC_all$SD)
multi_AIC_AUC_all$Upper <- exp(multi_AIC_AUC_all$Coefficient +1.96*multi_AIC_AUC_all$SD)

multi_AIC_AUC_all[,c(3,5,6,7)] <- round(multi_AIC_AUC_all[,c(3,5,6,7)],digits = 3)
multi_AIC_AUC_all$RR3 <- paste0(as.character(multi_AIC_AUC_all$RR), ' (',as.character(multi_AIC_AUC_all$Lower) ,'-',as.character(multi_AIC_AUC_all$Upper),')')


## add Stringency at threshold####
po_threshold <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) + 
                      urban_pop + airport_seats + Hiv + str_cum_death_per100K_0.1, data_analysis_fixed2,family = poisson) 

summary(po_threshold) 
AIC(po_threshold) #624.1713
AICc(po_threshold) # 626.5713

multi_AIC_threshold <- data.frame(coef(summary(po_threshold)))
multi_AIC_threshold$var <- rownames(multi_AIC_threshold)
multi_AIC_threshold <- multi_AIC_threshold[,-3]
names(multi_AIC_threshold) <- c("Coefficient","SD","p","var") 

multi_AIC_threshold <- multi_AIC_threshold[!grepl("(Intercept)", multi_AIC_threshold$var),]

multi_AIC_threshold$RR <- exp(multi_AIC_threshold$Coefficient)
multi_AIC_threshold$Lower <- exp(multi_AIC_threshold$Coefficient -1.96*multi_AIC_threshold$SD)
multi_AIC_threshold$Upper <- exp(multi_AIC_threshold$Coefficient +1.96*multi_AIC_threshold$SD)

multi_AIC_threshold[,c(3,5,6,7)] <- round(multi_AIC_threshold[,c(3,5,6,7)],digits = 3)
multi_AIC_threshold$RR4 <- paste0(as.character(multi_AIC_threshold$RR), ' (',as.character(multi_AIC_threshold$Lower) ,'-',as.character(multi_AIC_threshold$Upper),')')

## Supplementary table 3 exported####

WriteXLS(x=c('multi_AIC_AUC_all','multi_AIC_threshold'), ExcelFileName = './Results/Tables/Supplementary table 3 P3 multi_add_stringency.xlsx',  
         verbose = FALSE, row.names = T, col.names = TRUE,
         na = "",envir = parent.frame())


## Extended Data Fig. 6 plotting########
gr <- c("Urban population (% of total population)", ##'Refugee population by \ncountry or territory of origin',
        "Volume of international air travel",
        'Prevalence of HIV, total (% of population\nages 15-49)',
        'AUC of  stringency index',
        'Stringency index when cumulative deaths\nreached 0.1 per 100K population') #0·1

lab <- data.frame(v1=rep(c(0.45,0.35,0.25,0.15,0.05),1),
                  v2=rep(c(1),each=5),
                  v3=c(gr))


data_table <- ggplot(lab, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4, hjust=0, vjust=0.5,lineheight = .8) + 
  annotate("text", label = "Variable", x = 1, y = 0.55, hjust=0,vjust=0, fontface = "bold") +
  # annotate("text", label = "Subgroup", x = 1.75, y = 88, hjust=0,vjust=0.5, fontface = "bold") +
  xlim(1,2.5) +
  #ylim(0,0.6)+
  scale_y_continuous(expand = c(0.05,0.05))+
  theme_bw() +
  #geom_hline(yintercept=c(20.5,21.5)) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(0.5,0,3.0,0.2), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table


## AUC all of stringency#######

multi_AIC_AUC_all <- within(multi_AIC_AUC_all,{
  index <- NA
  index[p >= 0.05] <- 'black'
  index[Lower >= 1 & p < 0.05] <- 'red'
  index[Upper <= 1 & p < 0.05] <- 'blue'
})

multi_AIC_AUC_all$RR
multi_AIC_AUC_all$Lower
multi_AIC_AUC_all$Upper
multi_AIC_AUC_all$index
multi_AIC_AUC_all$var

#options(OutDec = ".")
dat<- data.frame(group = c(0.45,0.35,0.25,0.15,0.05),
                 cen = c(1.594,1.310,1.402,1.027,""),
                 low = c(1.218,1.034,1.104,0.743,""),
                 high = c(2.086,1.660,1.780,1.420,""),
                 index = c("red","red","red","black",""))
dat <- dat %>%
  mutate_at(c('cen','low','high','index'),as.character) %>% 
  mutate_at(c('cen','low','high'),as.numeric)

df <- data.frame(x1 = 1, x2 = 1, y1 = 0, y2 = 0.53)
#options(OutDec = "·")
p3 <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c('','black',"red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.02) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = 'Add AUC of  stringency index (AICc=627.65)', x = 1, y = 0.55,vjust=0,hjust=0.5, fontface = "bold") + #(AICc=552·85)
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Risk Ratio", y="") + 
  #ylim(0,0.6)+
  scale_y_continuous(expand = c(0.05,0.05))+
  scale_x_log10(limits = c(0.3,3.0), breaks = c(0.5,1.0,2.0))+ ## 
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0,0.5,0), "lines"))+
  theme(legend.position = "none")
p3


## Stringency at threshold#####

multi_AIC_threshold <- within(multi_AIC_threshold,{
  index <- NA
  index[p >= 0.05] <- 'black'
  index[Lower >= 1 & p < 0.05] <- 'red'
  index[Upper <= 1 & p < 0.05] <- 'blue'
})


multi_AIC_threshold$RR
multi_AIC_threshold$Lower
multi_AIC_threshold$Upper
multi_AIC_threshold$index
multi_AIC_threshold$var

dat<- data.frame(group = c(0.45,0.35,0.25,0.15,0.05),
                  cen = c(1.520,1.268,1.430,"",1.166),
                  low = c(1.163,0.997,1.127,"",0.877),
                  high = c(1.986,1.612,1.816,"",1.549),
                  index = c("red","black","red","", "black"))
dat <- dat %>%
  mutate_at(c('cen','low','high','index'),as.character) %>% 
  mutate_at(c('cen','low','high'),as.numeric)


p4 <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c('','black',"red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.02) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "Add stringency index when cumulative deaths\nreached 0.1 per 100K population (AICc=626.57)", x = 1, y = 0.55,vjust=0,hjust=0.5, fontface = "bold") + #0·1  553·18
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Risk Ratio", y="") + 
  #ylim(0,0.6)+
  scale_y_continuous(expand = c(0.05,0.05))+
  scale_x_log10(limits = c(0.4,3.0), breaks = c(0.5,1.0,2.0))+ ## 
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0,0.5,0), "lines"))+
  theme(legend.position = "none")
p4

library(gridExtra)

cairo_pdf('./Results/Extended Data/Extended Data Fig. 6 add stringency.pdf',width=15,height=6) #,family="Arial Unicode MS"
grid.arrange(data_table,p3,p4, ncol=3, widths = c(2,3,3))
dev.off()
