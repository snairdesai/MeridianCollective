library(splines)
library(Epi)
library(glmnet)
library(WriteXLS)
library(tidyverse)
library(reshape2)
library(mgcv)
library(MASS)
require(MESS)
library(dplyr)
library(reshape)
#library(reshape2)
#library(ggplot2)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##load data_for_analysing_mortality_1stWAVE updated.RData#######
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
load("./R data/data_for_analysing_mortality_1stWAVE updated.RData")

## Considering the underreporting rate
#data_analysis_fixed2$off_value <- log(data_analysis_fixed2$popsize / (data_analysis_fixed2$ratio))
data_analysis_fixed$cum_deaths_predicted_2nd <- as.integer(data_analysis_fixed$cum_deaths_2nd * data_analysis_fixed$ratio_expected_reported)

## scale cum_deaths_per_100k_1st as a new predictor
data_analysis_fixed$cum_deaths_per_100k_1st_scale <- scale(data_analysis_fixed$cum_deaths_per_100k_1st)

## add Testing_policy_1101_new_cat as a two-level predictor
median(data_analysis_fixed$Testing_policy_1101,na.rm = T)
data_analysis_fixed$Testing_policy_1101_cat <- data_analysis_fixed$Testing_policy_1101
data_analysis_fixed$Testing_policy_1101_cat[data_analysis_fixed$Testing_policy_1101_cat>=2] <- 'Above 2'
data_analysis_fixed$Testing_policy_1101_cat[is.na(data_analysis_fixed$Testing_policy_1101_cat)] <- '1'
data_analysis_fixed$Testing_policy_1101_cat <- factor(data_analysis_fixed$Testing_policy_1101_cat,levels = c("1", "Above 2"))

## re-set Source.Quality to two-level factor
data_analysis_fixed$Source.Quality[data_analysis_fixed$Source.Quality =="no data"|data_analysis_fixed$Source.Quality =="basic"] <- 'No to basic'
data_analysis_fixed$Source.Quality[data_analysis_fixed$Source.Quality =="good"|data_analysis_fixed$Source.Quality =="satisfactory"] <- 'Satisfactory to good'
data_analysis_fixed$Source.Quality <- factor(data_analysis_fixed$Source.Quality,levels = c("No to basic","Satisfactory to good"))


##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## Univariable model ####
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
library(lme4)
## remove outliers or countries with missing predictors
data_analysis_fixed2 <- data_analysis_fixed[-which(data_analysis_fixed$countryterritoryCode=="ERI"|
                                                     data_analysis_fixed$countryterritoryCode=="BDI"|
                                                     data_analysis_fixed$countryterritoryCode=="TZA"|
                                                     data_analysis_fixed$Hiv==999),]


hr <- lapply(c("pop_den", "urban_pop" ,
              "Pop_65_age" , "SEX",
               'gdp_per_capita', "HDI" ,
               "Current_expenditures_health" ,
               "vulnerable_index",
               "Burden_communicable" ,
               "Burden_non_communicable" ,
               "Hiv" , "Diabetes",
               'no_neighbour_cat','lat',
               "cum_deaths_per_100k_1st_scale", 
              "str_auc_all", 
              "Testing_policy_1101_cat", "Source.Quality","Testing_ratio_100K"), 
             function(var) {
               formula <- as.formula(paste("cum_deaths_predicted_2nd ~ offset(pop_log) + (1|Country) +  ", var))
               po <- glmer(formula, data_analysis_fixed2,family = poisson)  
               coef(summary(po))
             })


hr <- lapply(hr,function(x) x <- cbind(x,rownames(x)))
cc<- as.data.frame(do.call("rbind", hr))
cc[,1:4] <- apply(cc[,1:4],2,as.numeric)
cc <- cc[,-c(3,6,7)]
names(cc) <- c("Coefficient","SD","p","var") # names(cc) <- c("RR","Lower","Upper",'p',"var")

cc0 <- cc[!grepl("(Intercept)", cc$var),]

cc0$RR <- exp(cc0$Coefficient)
cc0$Lower <- exp(cc0$Coefficient -1.96*cc0$SD)
cc0$Upper <- exp(cc0$Coefficient +1.96*cc0$SD)

#### For result presentation###
variableall <- rep(c("Population density [people per sq. km of land area]", "Urban population [% of total population]",
                     "Population ages 65 and above [% of total population]" , 'Sex ratio (Male/Female)',
                     "GDP per capita [current US$]" ,"Human Development Index" , 
                     "Current health expenditure [% of GDP]",'Infectious disease resilience index',
                     "DALY rates per 100,000 individuals from communicable, neonatal, maternal & nutritional diseases",
                     "DALY rates per 100,000 individuals from non-communicable diseases",
                     "Prevalence of HIV, total (% of population ages 15-49)" ,
                     "Diabetes prevalence (% of population ages 20 to 79)", 
                     'Number of neighbours, above 0','Latitude',
                     "Per 100K population mortality in the first wave",
                     'AUC of  stringency index in the first wave',
                     'Testing policy on November 1st, above 2',
                     "Test data quality in the first wave, satisfactory to good",
                     "Total number of tests per 100K\npopulation as of 31 Dec. 2020"), each=1)


Group1 <- rep(c('Demographics'),times=4)
Group2 <- rep(c('Socioeconomic'),times=2)
Group3 <- rep(c('Health care'),times=2)
Group4 <- rep(c('Co-morbidities'),times=4)
Group5 <- rep(c('Geography'),times=2)
Group6 <- rep(c("First wave mortality"),times=1)
Group7 <- rep(c("First wave intervention"),times=1)
Group8 <- rep(c("First wave testing"),times=3)

Groupall <- c(Group1,Group2,Group3,Group4,Group5,Group6,Group7,Group8)

cc0$variable <- variableall
cc0$group <- Groupall
cc0 <-cc0 %>%
  arrange(factor(group, levels = factor(c('Demographics','Socioeconomic','Health care','Co-morbidities',"Geography",
                                          "First wave mortality","First wave intervention","First wave testing"))))

cc0[,c(3,5,6,7)] <- round(cc0[,c(3,5,6,7)],digits = 3)
cc0$RR2 <- paste0(as.character(cc0$RR), ' (',as.character(cc0$Lower) ,'-',as.character(cc0$Upper),')')

## Supplementary table 5#####
WriteXLS(x=c('cc0'), 
         ExcelFileName = './Results/Tables/Supplementary table 5 uni_2nd_wave.xlsx',  
         verbose = FALSE, row.names = T, col.names = TRUE,
         na = "",envir = parent.frame())


####Extended Data Fig. 8 plotting ####
### combine with the result of the first wave#####
library(ggplot2)
library(gridExtra)
gn <- c("",'Demographics', 'Socioeconomic', 'Travel', 'Health care','Co-morbidities', 
        'Readiness', 'Geography',"First wave mortality","First wave interventions","First wave testing")

lab0 <- data.frame(v1=rep(c(53,51,43,
                            39,35,
                            29.5,18,14,
                            10,8,6),1),
                   v2=rep(c(1),each=11),
                   v3=c(gn))

data_table0 <- ggplot(lab0, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4, hjust=0, vjust=0.5,lineheight = .8) + 
  annotate("text", label = "Category", x = 1, y = 55, hjust=0,vjust=0, fontface = "bold") +
  # annotate("text", label = "Subgroup", x = 1.75, y = 88, hjust=0,vjust=0.5, fontface = "bold") +
  xlim(1,2.5) +
  theme_bw() +
  #geom_hline(yintercept=c(20.5,21.5)) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(0.6,0,4.1,0.2), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table0
#grid.arrange(data_table0,data_table, ncol=2) #15 10


unique(cc0$variable)

gr <- c("", "Population density (people per sq. km of land area)", 
        "Urban population (% of total population)",                                                   
        #"Refugee population by country or territory of origin",                                                               
        "Population ages 65 and above (% of total population)" , "Sex ratio (Male/Female)",                                                                       
        "GDP per capita (current US$)", "Human development index" , 
        "Number of international airports", "Volume of international air travel", #Total seats in 
        #"International tourism, number of arrivals" ,# "Physicians (per 1,000 people)"  ,                                                                     
        "Current health expenditure (% of GDP)", 
        "Infectious disease resilience index",
        "DALY rates per 100,000 individuals from communicable,\nneonatal, maternal & nutritional diseases"  ,        
        "DALY rates per 100,000 individuals from non-communicable \ndiseases" , 
        "Prevalence of HIV, total (% of population ages 15-49)" ,"Diabetes prevalence (% of population ages 20-79)" ,
        "COVID-19 test capacity, yes" , "COVID-19 readiness status, adequate","Number of borders, above 0","Latitude",
        "Per 100K population mortality rate in the first wave" ,                                       
        "AUC of  stringency index in the first wave",                                                     
        "Testing policy on 1st November 2020, above 2" ,                                                       
        "Test data quality in the first wave, satisfactory to good",
        "Total number of tests per 100K population as of 31 Dec. 2020") #neighbours

lab <- data.frame(v1=rep(c(53,51,49,47, 
                           45,43,41,
                           39,
                           37,35,33,
                           29.5,25.5,22,
                           20,18,16,14,
                           12,10,8,6,4,2),1),
                  v2=rep(c(1),each=24),
                  v3=c(gr))


data_table <- ggplot(lab, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4, hjust=0, vjust=0.5,lineheight = .8) + 
  annotate("text", label = "Variable", x = 1, y = 55, hjust=0,vjust=0, fontface = "bold") +
  # annotate("text", label = "Subgroup", x = 1.75, y = 88, hjust=0,vjust=0.5, fontface = "bold") +
  xlim(1,2.5) +
  theme_bw() +
  #geom_hline(yintercept=c(20.5,21.5)) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(0.5,0,1.8,0.2), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table


## Univariate model
#options(OutDec = ".")

dat1 <- data.frame(group = c(51,49,47, 
                             45,43,41,
                             39,
                             37,35,33,
                             29.5,25.5,22,
                             20,18,16,14,
                             12,10,8,6,4,2),
                  cen = c(0.751,1.626,1.192,1.171,1.520,1.552,1.135,1.395,1.026,1.653,0.760,0.908,1.397,1.052,0.812,1.239,0.840,1.467,"","","","",""),
                  low = c(0.546,1.221,0.859,0.866,1.054,1.144,0.835,1.050,0.752,1.247,0.556,0.668,1.044,0.766,0.424,0.508,0.288,1.092,"","","","",""),
                  high = c(1.032,2.167,1.654,1.582,2.192,2.105,1.543,1.855,1.399,2.192,1.039,1.233,1.870,1.444,1.557,3.019,2.456,1.970,"","","","",""),
                  index = c("black","red","black","black","red","red","black","red","black","red","black","black","red","black","black","black","black","red","","","","",""))

dat1 <- dat1 %>%   
  mutate_at(c(2:4),funs(as.character))%>%   
  mutate_at(c(2:4),funs(as.numeric))

df <- data.frame(x1 = 1, x2 = 1, y1 = 1.5, y2 = 53)
#options(OutDec = "·")
p <- ggplot(dat1,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c("black","black", "red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.15) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "First wave", x = 1, y = 55, vjust=0,hjust=0.5, fontface = "bold") +
  annotate("text", label = "ND", x = 0.9, y = 2, vjust=0,hjust=0.5) +
  annotate("text", label = "ND", x = 0.9, y = 4, vjust=0,hjust=0.5) +
  annotate("text", label = "NA", x = 0.9, y = 6, vjust=0,hjust=0.5) +
  annotate("text", label = "ND", x = 0.9, y = 8, vjust=0,hjust=0.5) +
  annotate("text", label = "NA", x = 0.9, y = 10, vjust=0,hjust=0.5) +
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Risk Ratio", y="") + 
  scale_x_log10()+
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0.5,0.5,0.1), "lines"))+
  theme(legend.position = "none")
p

##2nd wave
#options(OutDec = ".")

cc0 <- within(cc0,{
  index <- NA
  index[p >= 0.05] <- 'black'
  index[Lower >= 1 & p < 0.05] <- 'red'
  index[Upper <= 1 & p < 0.05] <- 'blue'
})

#options(OutDec = ".")
cc0$RR
cc0$Lower
cc0$Upper
cc0$index

dat2 <- data.frame(group = c(51,49,47, 
                             45,43,41,
                             39,
                             37,35,33,
                             29.5,25.5,22,
                             20,18,16,14,
                             12,10,8,6,4,2),
                  cen = c(0.779,1.109,0.858,0.739,1.367,1.945,"","",1.091,3.026,0.584,0.632,2.767,0.898,"","",1.247,2.370,2.221,1.098,0.998,1.038,1.322),
                  low = c(0.443,0.651,0.473,0.450,0.719,1.168,"","",0.654,1.999,0.349,0.386,1.864,0.516,"","",0.204,1.520,1.435,0.577,0.353,0.360,0.760),
                  high = c(1.368,1.887,1.554,1.213,2.597,3.239,"","",1.823,4.582,0.978,1.034,4.109,1.561,"","",7.609,3.695,3.438,2.088,2.822,2.990,2.300),
                  index = c("black","black","black","black","black","red","","","black","red","blue","black","red","black","","","black","red","red","black","black","black","black"))
dat2 <- dat2 %>%   
  mutate_at(c(2:4),funs(as.character))%>%   
  mutate_at(c(2:4),funs(as.numeric))


#options(OutDec = "·")
p2 <- ggplot(dat2,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c("black","black", 'blue',"red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.15) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "Second wave", x = 1, y = 55, vjust=0,hjust=0.5, fontface = "bold") +
  annotate("text", label = "ND", x = 0.9, y = 37, vjust=0,hjust=0.5) +
  annotate("text", label = "ND", x = 0.9, y = 39, vjust=0,hjust=0.5) +
  annotate("text", label = "ND", x = 0.9, y = 16, vjust=0,hjust=0.5) +
  annotate("text", label = "ND", x = 0.9, y = 18, vjust=0,hjust=0.5) +
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Risk Ratio", y="") + 
  scale_x_log10()+
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0.5,0.5,0.1), "lines"))+
  theme(legend.position = "none")
p2

library(Cairo)
cairo_pdf('./Results/Extended Data/Extended Data Fig. 8 uni_1st_2nd.pdf',width=16,height=7.5) #,family="Arial Unicode MS"
grid.arrange(data_table0,data_table, p,p2,ncol=4, widths = c(2,4.5,2.5,2.5))
dev.off()
