### multibinomial
library(ggplot2)
library(ggrepel)
library(tidyverse)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##load data_for_analysing_mortality_1stWAVE updated.RData#######
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
load("./R data/data_for_analysing_mortality_1stWAVE updated.RData")

## remove outliers or countries with missing predictors
data_analysis_fixed2 <- data_analysis_fixed[-which(data_analysis_fixed$countryterritoryCode=="ERI"|
                                                     data_analysis_fixed$countryterritoryCode=="BDI"|
                                                     data_analysis_fixed$countryterritoryCode=="TZA"|
                                                     data_analysis_fixed$Hiv==999),]


## need the raw str_auc_all to generate the new outcome, so load combined data pre-analysis updated.RData and combine
names(data_analysis_fixed2)[35] <- "str_auc_all_scale"
load("~/Documents/work/Africa analysis/3. Manuscript/2. revised 2nd wave/Nature medicine/Final script for publication/R data/combined data pre-analysis.RData")
data_analysis_fixed2 <- left_join(data_analysis_fixed2,data_combine[,c(2,27)])

data_analysis_fixed2 <- within(data_analysis_fixed2,{
  outcome_cat <- NA
  outcome_cat[str_auc_all >= median(str_auc_all) & cum_deaths_per_100k_1st >= median(cum_deaths_per_100k_1st)] <- 'high_high'
  outcome_cat[str_auc_all >= median(str_auc_all)& cum_deaths_per_100k_1st < median(cum_deaths_per_100k_1st)] <- 'high_low'
  outcome_cat[str_auc_all < median(str_auc_all)& cum_deaths_per_100k_1st >= median(cum_deaths_per_100k_1st)] <- 'low_high'
  outcome_cat[str_auc_all < median(str_auc_all)& cum_deaths_per_100k_1st < median(cum_deaths_per_100k_1st)] <- 'low_low'
})


table(data_analysis_fixed2$outcome_cat)

# data_analysis_fixed2$Country[data_analysis_fixed2$outcome_cat=='high_high']
# data_analysis_fixed2$Country[data_analysis_fixed2$outcome_cat=='high_low']
# data_analysis_fixed2$Country[data_analysis_fixed2$outcome_cat=='low_high']
# data_analysis_fixed2$Country[data_analysis_fixed2$outcome_cat=='low_low']


## Figure 5A#####
options(scipen=999)
data_analysis_fixed2$outcome_cat <- factor(data_analysis_fixed2$outcome_cat, levels = c('high_high','high_low','low_high','low_low'))
p <- ggplot(data_analysis_fixed2, aes(x=str_auc_all, y=cum_deaths_per_100k_1st,color = outcome_cat)) + geom_point(size = 4) +
  geom_label_repel(label=data_analysis_fixed2$Country) + # , vjust = 0, hjust = 0, nudge_x = 0, angle = 30
  geom_hline(yintercept=median(data_analysis_fixed2$cum_deaths_per_100k_1st), linetype="dashed")+
  geom_vline(xintercept=median(data_analysis_fixed2$str_auc_all), linetype="dashed")+
  scale_x_log10()+
  scale_y_log10()+
  theme(axis.text = element_text(size = 10, colour = "black")) + #face = "bold",
  theme(panel.background = element_rect(fill = "white", colour = "grey5")) +
  theme(axis.title= element_text(size=14)) + #, face= "bold"
  xlab("AUC of stringency index") + ylab("Per 100K population mortality rate in the first wave")+
  theme(panel.grid.minor = element_blank(), panel.grid.major =   element_blank(),
        axis.line.y = element_blank(),
        axis.ticks.y = element_blank()) +
  theme(legend.position = "none")+
  annotate(geom="text", x=40, y=28, label='Low/High: 10 countries',
           size =4,hjust = 0.5,vjust=0.1)+ #color="#E69F00",
  annotate(geom="text", x=132, y=28, label='High/High: 11 countries',
           size =4,hjust = 0.8,vjust=0.1)+
  annotate(geom="text", x=40, y=0.01, label='Low/Low: 11 countries',
           size =4,hjust = 0.5)+
  annotate(geom="text", x=132, y=0.01, label='High/Low: 10 countries',
           size =4,hjust = 0.8)+
  theme(plot.margin = unit(c(1,1,1.5,1), "cm"))

library(Cairo)
cairo_pdf('./Results/Figures/Figure 5A cat.pdf',width=15,height=9) #,family="Arial Unicode MS"
p
dev.off()


require(foreign)
require(nnet)
require(ggplot2)
require(reshape2)
library(AICcmodavg)

####~~~~~~~~~~~~~~~~~~~~~~~~
####Univariable model######
####~~~~~~~~~~~~~~~~~~~~~~~~
data_analysis_fixed2$outcome_cat<- relevel(data_analysis_fixed2$outcome_cat, ref = 'low_low')

hr <- lapply(c("pop_den", "urban_pop" ,
               "Pop_65_age" , "SEX",
               'gdp_per_capita', "HDI" ,
               'airport_no',"airport_seats",
               "Current_expenditures_health" ,
               "vulnerable_index",
               "Burden_communicable" ,
               "Burden_non_communicable" ,
               "Hiv","Diabetes",
               'test_capacity',#"readiness",
               'lat'), ##'no_neighbour_cat'
             function(var) {
               formula <- as.formula(paste("outcome_cat ~  ", var))
               po <- multinom(formula, data_analysis_fixed2)  
               cbind(exp(cbind(OR = t(coef(po)), as.data.frame(confint(po,level=0.95)))))
             })


hr <- lapply(hr,function(x) x <- cbind(x,rownames(x)))
cc<- as.data.frame(do.call("rbind", hr))

names(cc)[10] <- "var"

cc0 <- cc[!grepl("(Intercept)", cc$var),]

#### For result presentation###
variableall <- rep(c("Population density [people per sq. km of land area]", "Urban population [% of total population]" ,
                   "Population ages 65 and above [% of total population]" ,'Sex ratio (Male/Female)',
                   "GDP per capita [current US$]" ,
                   "Human Development Index" ,
                   "Number of international airports", "Volume of international air travel",
                   "Current health expenditure [% of GDP]",
                   'Infectious disease resilience index',
                   "DALY rates per 100,000 individuals from communicable, neonatal, maternal & nutritional diseases",
                   "DALY rates per 100,000 individuals from non-communicable diseases",
                   "Prevalence of HIV, total (% of population ages 15-49)" ,
                   "Diabetes prevalence (% of population ages 20 to 79)", 
                   'COVID-19 test capacity','Latitude'), each=1)


Group1 <- rep(c('Demographics'),times=4)
Group2 <- rep(c('Socioeconomic'),times=2)
Group3 <- rep(c('Travel'),times=2)
Group4 <- rep(c('Health care'),times=2)
Group5 <- rep(c('Co-morbidities'),times=4)
Group6 <- rep(c('Readiness'),times=1)
Group7 <- rep(c('Geography'),times=1)

Groupall <- c(Group1,Group2,Group3,Group4,Group5,Group6,Group7)



cc0$variable <- variableall
cc0$group <- Groupall
cc0 <-cc0 %>%
  arrange(factor(group, levels = factor(c('Demographics','Socioeconomic','Travel','Health care','Co-morbidities','Readiness'))))

cc0[,1:9] <- round(cc0[,1:9],digits = 3)
cc0$OR_H_L <- paste0(as.character(cc0$OR.high_low), ' (',as.character(cc0$`2.5 %.high_low`) ,'-',as.character(cc0$`97.5 %.high_low`),')')
cc0$OR_L_H <- paste0(as.character(cc0$OR.low_high), ' (',as.character(cc0$`2.5 %.low_high`) ,'-',as.character(cc0$`97.5 %.low_high`),')')
cc0$OR_H_H <- paste0(as.character(cc0$OR.high_high), ' (',as.character(cc0$`2.5 %.high_high`) ,'-',as.character(cc0$`97.5 %.high_high`),')')


####~~~~~~~~~~~~~~~~~~~~~~~~
####Multivariable model######
####~~~~~~~~~~~~~~~~~~~~~~~~
## Using the following function to get AICc of predictors from low to high
# urban_pop 115.2215 vulnerable_index 119.4384 HDI 123.4113  pop_den 124.3457 airpot_seats 125.2395 gdp_per_capita 126.2846 no_neighbour 126.7187 
# SEX 127.2153 Hiv 127.5616  Diabetes 128.3988 Pop_65_age 128.4437 lat 128.8376  Burden_communicable 128.9266 airpot_no 129.0361 
#  test_capacity 129.7326  Current_expenditures_health 129.777 Burden_non_communicable 129.9806 

# test <- multinom(outcome_cat ~ lat, data = data_analysis_fixed2)
# #summary(test)
# AICc(test)
# z <- summary(test)$coefficients/summary(test)$standard.errors
# # 2-tailed Wald z tests to test significance of coefficients
# p <- (1 - pnorm(abs(z), 0, 1)) * 2
# p

aicc <- lapply(c("pop_den", "urban_pop" ,
                 "Pop_65_age" , "SEX",
                 'gdp_per_capita', "HDI" ,
                 'airport_no',"airport_seats",
                 "Current_expenditures_health" ,
                 "vulnerable_index",
                 "Burden_communicable" ,
                 "Burden_non_communicable" ,
                 "Hiv","Diabetes",
                 'test_capacity',#"readiness",
                 'lat'), ##'no_neighbour_cat'), 
             function(var) {
               formula <- as.formula(paste("outcome_cat ~  ", var))
               po <- multinom(formula, data_analysis_fixed2)  
               AICc(po)
             })


aicc <- lapply(aicc,function(x) x <- cbind(x,rownames(x)))
aicc1 <- as.data.frame(do.call("rbind", aicc))
aicc1 <- cbind(variableall,aicc1)


## choose variables with p values smaller than 0.2 and remove variables with correlation, finally choosen
## Best multivariable model####

po <- multinom(outcome_cat ~   urban_pop + vulnerable_index , data = data_analysis_fixed2)

## correlation r > 0.6
#  HDI and vulnerable, HDI and communicable, HDI and GDP per capita, 
#  population and airport seats, Communicable and non-communicable

summary(po) ##109.1323
AIC(po)
AICc(po) #114.7573

multi_AIC <- data.frame(cbind(exp(cbind(OR = t(coef(po)), as.data.frame(confint(po,level=0.95))))))
multi_AIC$var <- rownames(multi_AIC)
multi_AIC <- multi_AIC[!grepl("(Intercept)", multi_AIC$var),]
multi_AIC[,1:9] <- round(multi_AIC[,1:9],digits = 4)
multi_AIC$OR_H_L <- paste0(as.character(multi_AIC$OR.high_low), ' (',as.character(multi_AIC$X2.5...high_low) ,'-',as.character(multi_AIC$X97.5...high_low),')')
multi_AIC$OR_L_H <- paste0(as.character(multi_AIC$OR.low_high), ' (',as.character(multi_AIC$X2.5...low_high) ,'-',as.character(multi_AIC$X97.5...low_high),')')
multi_AIC$OR_H_H <- paste0(as.character(multi_AIC$OR.high_high), ' (',as.character(multi_AIC$X2.5...high_high) ,'-',as.character(multi_AIC$X97.5...high_high),')')


## second minimum AICc####
po2 <- multinom(outcome_cat ~  urban_pop , data = data_analysis_fixed2) 

summary(po2) 
AIC(po2) #112.8215
AICc(po2) #115.2215

multi_AIC2 <- data.frame(cbind(exp(cbind(OR = t(coef(po2)), as.data.frame(confint(po2,level=0.95))))))
multi_AIC2$var <- rownames(multi_AIC2)
multi_AIC2 <- multi_AIC2[!grepl("(Intercept)", multi_AIC2$var),]
multi_AIC2[,1:9] <- round(multi_AIC2[,1:9],digits = 4)
multi_AIC2$OR_H_L <- paste0(as.character(multi_AIC2$OR.high_low), ' (',as.character(multi_AIC2$X2.5...high_low) ,'-',as.character(multi_AIC2$X97.5...high_low),')')
multi_AIC2$OR_L_H <- paste0(as.character(multi_AIC2$OR.low_high), ' (',as.character(multi_AIC2$X2.5...low_high) ,'-',as.character(multi_AIC2$X97.5...low_high),')')
multi_AIC2$OR_H_H <- paste0(as.character(multi_AIC2$OR.high_high), ' (',as.character(multi_AIC2$X2.5...high_high) ,'-',as.character(multi_AIC2$X97.5...high_high),')')

##Supplementary table 4 #######
library(WriteXLS)
WriteXLS(x=c('cc0','multi_AIC','multi_AIC2'), ExcelFileName = './Results/Tables/Supplementary table 4 P1 uni_multi_logistic.xlsx',  
         verbose = FALSE, row.names = T, col.names = TRUE,
         na = "",envir = parent.frame())

####Figure 5B####
# Add header as test/label##

library(ggplot2)
library(gridExtra)
library(grid)

## plotting multivariable 2

multi_AIC$var

gr <- c("Urban population (% of total population)", 
        'Infectious disease resilience index')  ## 'Prevalence of HIV, total \n(% of population ages 15-49)'

lab <- data.frame(v1=rep(c(0.5,0.05),1),
                  v2=rep(c(1),each=2),
                  v3=c(gr))


data_table_multi <- ggplot(lab, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4.5, hjust=0, vjust=0.5,lineheight = .8) +
  annotate("text", label = "Variable", x = 1, y = 0.6, hjust=0,vjust=0, fontface = "bold",size=5) +
  # annotate("text", label = "Subgroup", x = 1.75, y = 88, hjust=0,vjust=0.5, fontface = "bold") +
  xlim(1,2.5) +
  #ylim(0,0.6)+
  scale_y_continuous(expand = c(0.1,0.1))+
  theme_bw() +
  #geom_hline(yintercept=c(20.5,21.5)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(),
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(),
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(1,0,3.6,0.05), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table_multi


## Add H_L
multi_AIC$index_H_L <- 'black'
multi_AIC <- within(multi_AIC,{
  index_H_L[X2.5...high_low > 1] <- 'red'
  index_H_L[X97.5...high_low < 1] <- 'blue'
})

multi_AIC$OR.high_low
multi_AIC$X2.5...high_low
multi_AIC$X97.5...high_low
multi_AIC$index_H_L


dat <- data.frame(group = c(0.5,0.05),
                  cen = c(10.5963,  4.5084),
                  low = c(1.4408, 0.7802),
                  high = c(77.9275, 26.0508),
                  index = c('red',"black"))

df <- data.frame(x1 = 1, x2 = 1, y1 = 0, y2 = 0.53)
p_multi2 <- ggplot(dat,aes(cen,group)) +
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c('black','red'))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.05) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "High/Low", x = 1, y = 0.6,vjust=0,hjust=0.5, fontface = "bold",size=5) +
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Odds Ratio", y="") +
  #ylim(0,0.6)+
  scale_y_continuous(expand = c(0.1,0.1))+
  scale_x_log10(limits=c(0.0005,150))+ ##limits = c(0.3,100), ,breaks = c(0.001,0.01,0.1,1.0,10)
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.title = element_text(size=14), #face="bold",
        plot.margin = unit(c(0.9,0,2.5,0), "lines"))+
  theme(legend.position = "none")
p_multi2



## Add L_H
multi_AIC$index_L_H <- 'black'
multi_AIC <- within(multi_AIC,{
  index_L_H[X2.5...low_high > 1] <- 'red'
  index_L_H[X97.5...low_high < 1] <- 'blue'
})

multi_AIC$OR.low_high
multi_AIC$X2.5...low_high
multi_AIC$X97.5...low_high
multi_AIC$index_L_H


dat <- data.frame(group = c(0.5,0.05),
                  cen = c(9.4633, 8.0150),
                  low = c(1.2756, 1.3112),
                  high = c( 70.2044, 48.9952),
                  index = c("red" ,"red"))

p_multi3 <- ggplot(dat,aes(cen,group)) +
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c('red'))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.05) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "Low/High", x = 1, y = 0.6,vjust=0,hjust=0.5, fontface = "bold",size=5) +
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Odds Ratio", y="") +
  #ylim(0,0.6)+
  scale_y_continuous(expand = c(0.1,0.1))+
  scale_x_log10(limits=c(0.0005,150))+ ## limits=c(0.0001,50),breaks = c(0.03,0.1,0.3,1.0,3.0)
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.title = element_text(size=14),
        plot.margin = unit(c(0.9,0,2.5,0), "lines"))+
  theme(legend.position = "none")
p_multi3


## Add H_H
multi_AIC$index_H_H <- 'black'
multi_AIC <- within(multi_AIC,{
  index_H_H[X2.5...high_high > 1] <- 'red'
  index_H_H[X97.5...high_high < 1] <- 'blue'
})

multi_AIC$OR.high_high
multi_AIC$X2.5...high_high
multi_AIC$X97.5...high_high
multi_AIC$index_H_H

dat <- data.frame(group = c(0.5,0.05),
                  cen = c(18.1020, 10.1357),
                  low = c(2.2599, 1.5662),
                  high = c(144.9974,  65.5925),
                  index = c("red","red"))



p_multi4 <- ggplot(dat,aes(cen,group)) +
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c('red'))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.05) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "High/High", x = 1, y = 0.6,vjust=0,hjust=0.5, fontface = "bold",size=5) +
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Odds Ratio", y="") +
  #ylim(0,0.6)+
  scale_y_continuous(expand = c(0.1,0.1))+
  scale_x_log10(limits=c(0.0005,150))+ ## ,breaks = c(0.03,0.1,0.3,1.0,3.0)
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.title = element_text(size=14),
        plot.margin = unit(c(0.9,0,2.5,0), "lines"))+
  theme(legend.position = "none")
p_multi4


cairo_pdf('./Results/Figures/Figure 5B logistic multi.pdf',width=15.5,height=4) #,family="Arial Unicode MS"
grid.arrange(data_table_multi, p_multi2,p_multi3,p_multi4, ncol=4, widths = c(3,3.5,3,3))
dev.off()


library(grid)
library(gridExtra)
options(scipen=999)

p2_combine <- grid.arrange(data_table_multi, p_multi2,p_multi3,p_multi4, ncol=4, widths = c(3,3.5,3,3)) #hjust = 1.9,


library(Cairo)
cairo_pdf('./Results/Figures/Figure 5 logistic multia.pdf',width=15.5,height=14) #,family="Arial Unicode MS"
grid.arrange(p, p2_combine, ncol=1, heights=c(8,2.8))
dev.off()

## Univariate model plotting
### Extended Data Fig. 7 remove readiness and number of borders######
# Add header as test/label##
library(ggplot2)
library(gridExtra)

unique(cc0$group)

gn <- c("",'Demographics', 'Socioeconomic', 'Travel', 'Health care','Co-morbidities', 
        'Readiness', 'Geography')

lab0 <- data.frame(v1=rep(c(39,37,29,
                            25,21,
                            15.5,4,2),1),
                   v2=rep(c(1),each=8),
                   v3=c(gn))

data_table0 <- ggplot(lab0, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4, hjust=0, vjust=0.5,lineheight = .8) + 
  annotate("text", label = "Category", x = 1, y = 40, hjust=0,vjust=0, fontface = "bold") +
  # annotate("text", label = "Subgroup", x = 1.75, y = 88, hjust=0,vjust=0.5, fontface = "bold") +
  xlim(1,2.5) +
  theme_bw() +
  #geom_hline(yintercept=c(20.5,21.5)) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(0.6,0,1.3,0.2), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table0
#grid.arrange(data_table0,data_table, ncol=2) #15 10


unique(cc0$variable)

gr <- c("", "Population density (people per sq. km of land area)", 
        "Urban population (% of total population)",                                                   
        #"Refugee population by country or territory of origin",                                                               
        "Population ages 65 and above (% of total population)" , "Sex ratio (Male/Female)",                                                                       
        "GDP per capita (current US$)", "Human development index" , 
        "Number of international airports", "Volume of international air travel",
        #"International tourism, number of arrivals" ,# "Physicians (per 1,000 people)"  ,                                                                     
        "Current health expenditure (% of GDP)", 
        "Infectious disease resilience index",
        "DALY rates per 100,000 individuals from communicable,\nneonatal, maternal & nutritional diseases"  ,        
        "DALY rates per 100,000 individuals from non-communicable \ndiseases" , 
        "Prevalence of HIV, total (% of population ages 15-49)" ,"Diabetes prevalence (% of population ages 20-79)" ,
        "COVID-19 test capacity, yes" ,"Latitude")


lab <- data.frame(v1=rep(c(39,37, 
                           35,33,31,
                           29,
                           27,25,23,21,19,
                           15.5,11.5,
                           8,6,4,2),1),
                  v2=rep(c(1),each=17),
                  v3=c(gr))


data_table <- ggplot(lab, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4, hjust=0, vjust=0.5,lineheight = .8) + 
  annotate("text", label = "Variable", x = 1, y = 40, hjust=0,vjust=0, fontface = "bold") +
  # annotate("text", label = "Subgroup", x = 1.75, y = 88, hjust=0,vjust=0.5, fontface = "bold") +
  xlim(1,2.5) +
  theme_bw() +
  #geom_hline(yintercept=c(20.5,21.5)) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(0.5,0,1.3,0.2), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table



cc0$index_H_L <-'black'
cc0 <- within(cc0,{
  index_H_L[`2.5 %.high_low` > 1] <- 'red'
  index_H_L[`97.5 %.high_low` < 1] <- 'blue'
})



cc0$OR.high_low
cc0$`2.5 %.high_low`
cc0$`97.5 %.high_low`
cc0$index_H_L

dat <- data.frame(group = c(37, 
                            35,33,31,
                            29,
                            27,25,23,21,19,
                            15.5,11.5,
                            8,6,4,2),
                  cen = c(0.912,4.532,0.345,1.619,1.265,2.349,1.702,1.783,0.944,2.202,0.710,0.894,1.198,0.682,1.945,0.700),
                  low = c(0.437,1.208,0.053,0.451,0.307,0.713,0.605,0.294,0.424,0.676,0.283,0.376,0.353,0.268,0.322,0.279),
                  high = c(1.903,16.993,2.228,5.811,5.212,7.738,4.783,10.815,2.103,7.172,1.779,2.127,4.066,1.739,11.756,1.758),
                  index = c("black","red","black","black","black","black","black","black","black","black","black","black","black","black","black","black"))

df <- data.frame(x1 = 1, x2 = 1, y1 = 2, y2 = 38)
p <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c("black",'red'))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.15) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "High/Low", x = 1, y = 40, vjust=0,hjust=0.5, fontface = "bold") +
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Odds Ratio", y="") + 
  scale_x_log10()+
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0,0.5,0.1), "lines"))+
  theme(legend.position = "none")
p


cc0$index_L_H <-'black'
cc0 <- within(cc0,{
  index_L_H[`2.5 %.low_high` > 1] <- 'red'
  index_L_H[`97.5 %.low_high` < 1] <- 'blue'
})

cc0$OR.low_high
cc0$`2.5 %.low_high`
cc0$`97.5 %.low_high`
cc0$index_L_H

dat <- data.frame(group = c(37, 
                            35,33,31,
                            29,
                            27,25,23,21,19,
                            15.5,11.5,
                            8,6,4,2),
                  cen = c(0.578,4.392,0.778,0.941,1.113,2.746,1.226,1.831,0.716,3.666,0.564,1.207,2.127,0.447,1.250,1.309),
                  low = c(0.200,1.176,0.291,0.245,0.254,0.832,0.396,0.305,0.297,1.083,0.218,0.534,0.731,0.126,0.221,0.552),
                  high = c(1.667,16.403,2.078,3.615,4.882,9.068,3.792,10.990,1.728,12.414,1.463,2.727,6.193,1.590,7.084,3.105),
                  index = c("black","red","black","black","black","black","black","black","black","red","black","black","black","black","black","black"))


p1 <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c("black",'red'))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.15) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "Low/High", x = 1, y = 40, vjust=0,hjust=0.5, fontface = "bold") +
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Odds Ratio", y="") + 
  scale_x_log10()+
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0,0.5,0.1), "lines"))+
  theme(legend.position = "none")
p1

cc0$index_H_H <-'black'
cc0 <- within(cc0,{
  index_H_H[`2.5 %.high_high` > 1] <- 'red'
  index_H_H[`97.5 %.high_high` < 1] <- 'blue'
})

cc0$OR.high_high
cc0$`2.5 %.high_high`
cc0$`97.5 %.high_high`
cc0$index_H_H

dat <- data.frame(group = c(37, 
                            35,33,31,
                            29,
                            27,25,23,21,19,
                            15.5,11.5,
                            8,6,4,2),
                  cen = c(0.136,9.898,1.004,2.280,2.653,4.233,1.685,3.342,0.716,5.866,0.604,0.853,1.777,0.870,2.222,0.869),
                  low = c(0.014,2.348,0.488,0.638,0.768,1.263,0.606,0.613,0.304,1.646,0.240,0.362,0.604,0.418,0.375,0.366),
                  high = c(1.327,41.731,2.065,8.152,9.167,14.184,4.684,18.228,1.687,20.903,1.518,2.005,5.227,1.809,13.179,2.065),
                  index = c("black","red","black","black","black","red","black","black","black","red","black","black","black","black","black","black"))


p2 <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c("black",'red'))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.15) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "High/High", x = 1, y = 40, vjust=0,hjust=0.5, fontface = "bold") +
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Odds Ratio", y="") + 
  scale_x_log10()+
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0.2,0.5,0.1), "lines"))+
  theme(legend.position = "none")
p2

cairo_pdf('./Results/Extended Data/Extended Data Fig. 7 logistic uni.pdf',width=18,height=8) #,family="Arial Unicode MS"
grid.arrange(data_table0,data_table, p,p1,p2, ncol=5, widths = c(1.5,5,3,3,3))
dev.off()

