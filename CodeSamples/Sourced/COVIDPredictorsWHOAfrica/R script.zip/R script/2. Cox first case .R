##cox regression model
library(survival)
library(glmnet)
library(WriteXLS)
library(tidyverse)
library(readxl)

##load combined data pre-analysis updated.RData#####
load("~/Documents/work/Africa analysis/Final script for publication/R data/combined data pre-analysis.RData")

data_analysis_fixed <- data_combine

##re-set readiness to two levels
data_analysis_fixed$readiness[data_analysis_fixed$readiness=='limited'|data_analysis_fixed$readiness=='moderate'|is.na(data_analysis_fixed$readiness)] <- 'limited to moderate'
data_analysis_fixed$readiness <- factor(data_analysis_fixed$readiness,levels = c('limited to moderate','adequate'))

##set test_capacity as factors
data_analysis_fixed$test_capacity <- factor(data_analysis_fixed$test_capacity,levels = c('no','yes'))

##re-set no_neighbour as 2-level factors
data_analysis_fixed <- within(data_analysis_fixed,{
  no_neighbour_cat <- NA
  no_neighbour_cat[no_neighbour==0] <- 'zero'
  no_neighbour_cat[no_neighbour>0] <- 'non_zero'
})

data_analysis_fixed$no_neighbour_cat <- factor(data_analysis_fixed$no_neighbour_cat, levels = c('zero','non_zero'))


## standardise continuous variables
#save raw pop for later use
data_analysis_fixed$popsize <- data_analysis_fixed$pop
data_analysis_fixed <- data_analysis_fixed %>%
  mutate_at(c(3:17,21,26:28), scale)

## add missing indicator for HIV
a <- data_analysis_fixed %>%
  mutate_at(c('Hiv'),
            ~replace(., is.na(.),999))
a <- a %>%
  mutate(Hiv.missing=ifelse(Hiv==999,1, 0))
a <- a[,c(1:2,29:34,3:16,37,17:20,35,21:28,36)]
data_analysis_fixed <-a

save(data_analysis_fixed,
     file="./R data/data_for_analysing_1stCASE.RData")

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
### Extended Data Fig. 2 Correlation matrix#####
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
cor_all <- data_analysis_fixed[,c(1:2,9:22,24,25,26,28,29,30)] 
cor_all$ratio_expected_reported <- scale(cor_all$ratio_expected_reported) ##only scale for correlation matrix

cor_all[cor_all==999] <- NA
cor_all <- cor_all %>%   
  mutate_at(c(3:22),funs(as.numeric))

cor_all <- cor_all[-which(cor_all$Country == 'United Republic of Tanzania'),]
cor_all <- cor_all[-which(cor_all$countryterritoryCode=="ERI"|cor_all$countryterritoryCode=="BDI"),]

dat_cor <- cor_all[,3:21]  ## ratio_expected_reported doesn't enter the model as a predictor, so remove?

a1 <- dat_cor[complete.cases(dat_cor$Hiv),] ## finally 42 countries without missing data


names(a1) <- c("Population, total","Population density\n(people per sq. km of land area)", "Urban population (% of total population)" ,
               "Population ages 65 and above\n(% of total population)" , 'Sex ratio (Male/Female)',
               "GDP per capita (current US$)" ,"Human development index",
                "Number of international airports", "Volume of international air travel",
               "Current health expenditure (% of GDP)",'Infectious disease resilience index',
               "DALY rates per 100,000 individuals from communicable,\nneonatal, maternal& nutritional diseases",
               "DALY rates per 100,000 individuals\nfrom non-communicable diseases",
               "Prevalence of HIV, total (% of population ages 15-49)" ,
               "Diabetes prevalence (% of population ages 20-79)",
               'COVID-19 test capacity',"COVID-19 readiness status",
               'Number of borders','Latitude')
               #'Ratio of total COVID-19 mortality\nto reported COVID-19 mortality') 


res <- cor(a1, method = "spearman",use = "complete.obs")

## correlation r > 0.6
#  HDI and vulnerable, HDI and communicable, HDI and GDP per capita, 
#  population and airport seats, Communicable and non-communicable,
#  ratio and GDP, ratio and HDI

library(corrplot)


library(Cairo)
cairo_pdf('./Results/Extended Data/Extended Data Fig. 2.pdf',width=33,height=25) #,family="Arial Unicode MS"
par(mar=c(0,0,0,0))
col <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD", "#4477AA"))
corrplot(res, method="color", col=col(200),  
         type="lower", order="original", #order="hclust", 
         addCoef.col = "black", # Add coefficient of correlation
         tl.col="black", tl.srt=45, #Text label color and rotation
         tl.cex = 2,cl.align.text="l",tl.offset=1,number.cex=2,number.digits=3,
         # hide correlation coefficient on the principal diagonal
         diag=FALSE,cl.cex=2,
         mar = c(0, 0, 0, 0))
dev.off()

## COX regression model for first case####
dat <- data_analysis_fixed
dat$start <- as.Date("2020-02-25") ## the first day of the week when the first case occurred
dat <- dat %>%
  mutate(event= ifelse(is.na(first_case),0,1))
today <- as.Date('2021-03-26') ## the date when the analysis was performed
dat <- dat %>%
  mutate(end= ifelse(event==0,today,first_case))
dat$end <- as.Date(dat$end,origin = "1970-01-01")
dat$ftime <- as.numeric(dat$end-dat$start)

data_analysis_fixed <- dat

## Univariable model#####

hr <- lapply(c('pop',"pop_den", "urban_pop" , 
               "Pop_65_age", "SEX",
               'gdp_per_capita', "HDI" , 
               'airport_no',"airport_seats",
               "Current_expenditures_health" ,
               "vulnerable_index",
               'test_capacity', "readiness",
               'no_neighbour_cat','lat'),
             function(var) {
               formula <- as.formula(paste("Surv(ftime, event) ~ ", var))
               cox <- coxph(formula, data_analysis_fixed)
               cbind(exp(cbind(HR = coef(cox), confint.default(cox))),coef(summary(cox))[,5])
             })


hr <- lapply(hr,function(x) x <- cbind(x,rownames(x)))
cc<- as.data.frame(do.call("rbind", hr))
cc[,1:4] <- apply(cc[,1:4],2,as.numeric)
names(cc) <- c("HR","Lower","Upper",'p',"var")
cc <- cc %>%
  dplyr::select("var", 1:4)

cc0 <- cc

variableall <- rep(c("Population, total" ,
                   "Population density [people per sq. km of land area]",
                   "Urban population [% of total population]" ,
                   "Population ages 65 and above [% of total population]",
                   'Sex ratio (Male/Female)',
                   "GDP per capita [current US$]" ,
                   "Human development index" ,  
                   "Number of international airports", 
                   "Volume international air travel",
                   "Current health expenditure [% of GDP]",
                   'Infectious disease resilience index',
                   'COVID-19 test capacity',"COVID-19 readiness status",
                   'Number of borders, above 0',
                   'Latitude'), each=1)


Group1 <- rep(c('Demographics'),times=5)
Group2 <- rep(c('Socioeconomic'),times=2)
Group3 <- rep(c('Travel'),times=2)
Group4 <- rep(c('Health care'),times=2)
Group5 <- rep(c('Readiness'),times=2)
Group6 <- rep(c('Geography'),times=2)
Groupall <- c(Group1,Group2,Group3,Group4,Group5,Group6)

cc0$variable <- variableall
cc0$group <- Groupall
cc0 <-cc0 %>%
  arrange(factor(group, levels = factor(c('Demographics','Socioeconomic','Travel','Health care',#'Co-morbidities',
                                          'Readiness','Situation in nearby countries'))))
cc0[,2:5] <- round(cc0[,2:5],digits = 3)
cc0$HR2 <- paste0(as.character(cc0$HR), ' (',as.character(cc0$Lower) ,'-',as.character(cc0$Upper),')')


### Multivariable model######
## choose variables with p values smaller than 0.2
library(AICcmodavg)
library(MASS)
cox <- coxph(Surv(ftime, event)
             ~ urban_pop + airport_no + airport_seats +
               Current_expenditures_health + vulnerable_index + 
               test_capacity + readiness + no_neighbour_cat ,
             data = data_analysis_fixed) ## removed because correlation r >0.6 (below), pop + HDI,  when chose related variables we chose the one with smaller p value from univariable model 

## correlation r > 0.6
#  HDI and vulnerable, HDI and communicable, HDI and GDP per capita, 
#  population and airport seats, Communicable and non-communicable

AICc(cox, return.K = FALSE, second.ord = TRUE, nobs = NULL) #254.3715


#stepAIC(cox) # AIC

## library stepAICc function in the folder
stepAICc(cox) #AICc

# Best model with the smallest AICc####
cox_AIC <- coxph(Surv(ftime, event)
                 ~  urban_pop + airport_no + airport_seats +
                   Current_expenditures_health + 
                   test_capacity +  no_neighbour_cat ,
                 data = data_analysis_fixed)
AICc(cox_AIC, return.K = FALSE, second.ord = TRUE, nobs = NULL) ##  248.854


multi_AIC <- data.frame(cbind(exp(cbind(HR = coef(cox_AIC), confint.default(cox_AIC))),p=coef(summary(cox_AIC))[,5]))
multi_AIC$var <- rownames(multi_AIC)
multi_AIC <- multi_AIC[!grepl("missing", multi_AIC$var),]
multi_AIC[,1:4] <- round(multi_AIC[,1:4],digits = 3)
multi_AIC$HR3 <- paste0(as.character(multi_AIC$HR), ' (',as.character(multi_AIC$X2.5..) ,'-',as.character(multi_AIC$X97.5..),')')


## 2nd smallest AICc, AICc=251.5261-248.854>2
cox_AIC2 <- coxph(Surv(ftime, event)
                 ~  urban_pop + airport_no + airport_seats +
                   Current_expenditures_health +  
                   test_capacity + readiness + no_neighbour_cat ,
                 data = data_analysis_fixed)
AICc(cox_AIC2, return.K = FALSE, second.ord = TRUE, nobs = NULL) ##  251.5261


## Supplementary table 2 get the result exported#####
## combine uni and multi
uni_multi <- left_join(cc0[,c(7,6,8,1)],multi_AIC[,c(5,6)])
uni_multi <- uni_multi[,-4]
WriteXLS(x=c('cc0','multi_AIC','uni_multi'), ExcelFileName = './Results/Tables/Supplementary table 2_uni_multi_1stCASE.xlsx',  
         verbose = FALSE, row.names = T, col.names = TRUE,
         na = "",envir = parent.frame())

##### Figure 3 - Get the result Visualised ####
# Add header as test/label##
library(ggplot2)
library(gridExtra)

unique(cc0$group)

gn <- c("",'Demographics', 'Socioeconomic', 'Travel', 'Health care',#'Co-morbidities', 
        'Readiness', 'Geography')

lab0 <- data.frame(v1=rep(c(32,30,20,
                            16,12,
                            8,4),1),
                   v2=rep(c(1),each=7),
                   v3=c(gn))


data_table0 <- ggplot(lab0, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4, hjust=0, vjust=0.5,lineheight = .8) + 
  annotate("text", label = "Category", x = 1, y = 33, hjust=0,vjust=0, fontface = "bold") +
  xlim(1,2.5) +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(0.6,0,3.1,0.2), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table0


unique(cc0$variable)

gr <- c("","Population, total",  "Population density (people per sq. km of land area)", 
        "Urban population (% of total population)",                                                   
        #"Refugee population by country or territory of origin",                                                               
        "Population ages 65 and above (% of total population)" , "Sex ratio (Male/Female)",                                                                       
        "GDP per capita (current US$)", "Human development index" , 
        "Number of international airports", "Volume of international air travel", #Total seats in 
        #"International tourism, number of arrivals" ,# "Physicians (per 1,000 people)"  ,                                                                     
        "Current health expenditure (% of GDP)", 
        "Infectious disease resilience index",
        #"DALY rates per 100,000 individuals from communicable,\nneonatal, maternal & nutritional diseases"  ,        
        #"DALY rates per 100,000 individuals from non-communicable \ndiseases" , 
        #"Prevalence of HIV, total (% of population ages 15-49)" ,"Diabetes prevalence (% of population ages 20-79)" ,
        "COVID-19 test capacity, yes" , "COVID-19 readiness status, adequate","Number of borders, above 0","Latitude") #neighbours


lab <- data.frame(v1=rep(c(32,30,28,26,24,
                           22,20,18,
                           16,14,12,10,
                           8,6,4,2),1),
                  v2=rep(c(1),each=16),
                  v3=c(gr))


data_table <- ggplot(lab, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4, hjust=0, vjust=0.5,lineheight = .8) + 
  annotate("text", label = "Variable", x = 1, y = 33, hjust=0,vjust=0, fontface = "bold") +
  # annotate("text", label = "Subgroup", x = 1.75, y = 88, hjust=0,vjust=0.5, fontface = "bold") +
  xlim(1,2.5) +
  theme_bw() +
  #geom_hline(yintercept=c(20.5,21.5)) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(0.5,0,1.3,0.2), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table


## Univariable model
cc0 <- within(cc0,{
  index <- NA
  index[p >= 0.05] <- 'black'
  index[Lower >= 1 & p < 0.05] <- 'red'
  index[Upper <= 1 & p < 0.05] <- 'blue'
})

cc0$HR
cc0$Lower
cc0$Upper
cc0$index

dat <- data.frame(group = c(30,28,26,24,
                            22,20,18,
                            16,14,12,10,
                            8,6,4,2),
                  cen = c(2.002,0.826,1.265,1.028,1.219,1.198,1.212,1.381,1.806,0.603,1.253,3.643,2.628,1.974,0.873),
                  low = c(1.408,0.608,0.963,0.754,0.900,0.906,0.904,1.007,1.358,0.428,0.908,1.844,1.138,0.817,0.646),
                  high = c(2.847,1.122,1.661,1.402,1.652,1.583,1.626,1.892,2.403,0.849,1.729,7.200,6.067,4.773,1.179),
                  index = c("red","black","black","black","black","black","black","red","red","blue","black","red","red","black","black"))

df <- data.frame(x1 = 1, x2 = 1, y1 = 2, y2 = 31)

p <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c("black", "blue", "red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.15) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "Univariable", x = 1, y = 33, vjust=0,hjust=0.5, fontface = "bold") +
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Hazard Ratio", y="") + 
  scale_x_log10()+
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0,0.5,0.1), "lines"))+
  theme(legend.position = "none")
p



## multivariable
multi_AIC <- within(multi_AIC,{
  index <- NA
  index[p >= 0.05] <- 'black'
  index[X2.5.. >= 1 & p < 0.05] <- 'red'
  index[X97.5.. <= 1 & p < 0.05] <- 'blue'
})

multi_AIC$var
multi_AIC$HR
multi_AIC$X2.5..
multi_AIC$X97.5..
multi_AIC$index

dat <- data.frame(group = c(30,28,26,24,
                  22,20,18,
                  16,14,12,10,
                  8,6,4,2),
                  cen = c("","",1.404,"","","","",1.475,1.519,0.754,"",3.861,"",2.866,""),
                  low = c("","",1.011,"","","","",1.017,1.095,0.539,"",1.829,"",1.122,""),
                  high = c("","",1.949,"","","","",2.139,2.106,1.054,"",8.151,"",7.316,""),
                  index = c("","",'red',"","","","","red",'red',"black","",'red',"","red",""))
dat <- dat %>%
  mutate_at(c('cen','low','high','index'),as.character) %>% 
  mutate_at(c('cen','low','high'),as.numeric)
dat <- dat[complete.cases(dat),]

p2 <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c("black","red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.15) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "Multivariable", x = 1, y = 33,vjust=0,hjust=0.5, fontface = "bold") + #(AICc=250·01)
  labs(x="Hazard Ratio", y="") +
  scale_x_log10() +#, limits = c(0.2,9), breaks = c(0.3,1.0,3.0,5.0)
  #scale_x_log10()+
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0,0.5,0.1), "lines"))+
  theme(legend.position = "none")
p2

cairo_pdf('./Results/Figures/Figure 3 cox regression.pdf',width=12,height=6.5) #,family="Arial Unicode MS"
grid.arrange(data_table0,data_table, p,p2, ncol=4, widths = c(1.5,5,2.5,3)) 
dev.off()
