### load combined data pre-analysis
load("./R data/combined data pre-analysis.RData")

## Figure 1A timeline ####
data_timeline <- melt(data_combine[,c(1,29,30)],id='Country') 
data_timeline$variable <- as.character(data_timeline$variable)
data_timeline$variable[data_timeline$variable == 'first_case'] <- 'First case'
data_timeline$variable[data_timeline$variable == 'first_death'] <- 'First death'

data_timeline$variable <- factor(data_timeline$variable,levels = c("First case","First death"))

break.vec <- seq(from = as.Date("2020-02-25"), to = as.Date('2021-03-14'),
                 by = "month")

p_time <- ggplot() +
  geom_segment(data=data_combine, aes(x=first_case, y=reorder(Country, first_case), xend=as.Date('2021-03-26'), yend=Country),colour="grey") +
  geom_point(data=data_timeline, aes(x=value, y=Country,color = variable,shape= variable), size=4,stroke = 1)+
  scale_shape_manual(values=c(0, 1))+
  scale_x_date(breaks =break.vec, date_labels = "%b %d")+
  #scale_color_manual(values=c('#999999','#E69F00', '#56B4E9'))+
  theme(axis.text = element_text(size = 15, face = "bold",colour = "black")) +
  theme(panel.background = element_rect(fill = "white", colour = "grey5")) +
  theme(axis.title= element_text(size=17, face= "bold")) +
  xlab("Date") + ylab("Country")+
  theme(legend.position = "right") +
  geom_text(data=data_combine, aes(x=first_case, y=Country, label = format(first_case,"%b %d")),nudge_x = -10,size = 5)+
  geom_vline(xintercept = c(as.Date('2020-10-31'),as.Date('2021-03-14')), linetype="dashed", 
             color = "red", size=1) +
  theme(panel.grid.minor = element_blank(), panel.grid.major =   element_blank(),
        axis.line.y = element_blank(),
        axis.ticks.y = element_blank())+
  theme(legend.position = c(0.0555, 0.935))+
  theme(legend.title = element_blank())+
  theme(legend.text = element_text(size=13,
                                   face="bold"))+ 
  #theme(axis.text = element_text(angle = 40,hjust = 1))+
  annotate("text", label = 'First wave ended on 31 Oct 2020', x = as.Date('2020-10-29'), y = 33,
           vjust=0,hjust=0.5, fontface = "bold",angle = 90,size=8)+
  annotate("text", label = 'Second wave ended on 14 Mar 2021', x = as.Date('2021-03-12'), y = 32,
           vjust=0,hjust=0.5, fontface = "bold",angle = 90,size=8)

# ggtitle("A Date of the first case and the first death") +
# theme(plot.title = element_text(size=18))# 20 10
p_time

library(Cairo)
cairo_pdf("./Results/Figures/Figure 1A timeline.pdf",width=25,height=9) #,family="Arial Unicode MS" # for paperwidth=16.5,height=12.5
p_time
dev.off()


## Figure 1B. end of first curve for deaths######
new_death <- WHO_cases_and_deaths[,c(1,2,6)]
new_death <- spread(new_death,country,deaths)
new_death$sum <- rowSums(new_death[,2:48])
smoothCounts1 <-ksmooth(new_death$date,new_death$sum,kernel="normal",bandwidth=21,n.points = length(new_death$date))
# dsmooth1 <-diff(smoothCounts1$y)
# locmax1 <-sign(c(0,dsmooth1))>0 & sign(c(dsmooth1,0))<0
# points1 <- data.frame(x=smoothCounts1$x[locmax1],y=smoothCounts1$y[locmax1])

break.vec <- seq(from = as.Date("2020-02-25"), to = as.Date('2021-03-26'),
                 by = "2 months")

p_death <- ggplot() +
  geom_bar(data=new_death, aes(x=date, y=sum),stat="identity", position=position_dodge(),colour = 'grey')+ 
  geom_line(data=new_death, aes(x=date,y=smoothCounts1$y),colour = 'blue',cex=1.5)+
  #geom_point(data=points1,aes(x,y),cex=5,shape=1,colour = 'red',size=5,stroke = 3) +
  xlab("Date") + ylab("Count") + 
  scale_x_date(breaks =break.vec, date_labels = "%b %d")+
  theme(axis.title= element_text(size=25, face= "bold", vjust=0.5, hjust=0.5)) + 
  theme(axis.text = element_text(color = "black", size=20)) +
  theme(axis.line = element_line(size = 0.8, colour = "black")) + 
  theme(panel.background = element_rect(fill = "transparent", color = "transparent"))+
  #theme(legend.position = c(0.3, 0.9))+
  theme(plot.margin=unit(c(0.5,0.5,0.5,0.5),"cm"))+
  theme(legend.position="none")+
  #ggtitle(expression(bold("B")~"Daily new deaths")) + #B Daily new deaths
  theme(plot.title = element_text(hjust = 0,size = 28)) +
  geom_vline(xintercept = c(as.Date('2020-10-31'),as.Date('2021-03-14')), linetype="dashed", 
             color = "red", size=1)## should be -10 if generate today
#geom_hline(yintercept=max(smoothCounts1$y), linetype="dashed",colour='orange')
p_death

library(Cairo)
cairo_pdf("./Results/Figures/Figure 1B death curve.pdf",width=12.5,height=8.5) #,family="Arial Unicode MS"width=16.5,height=12.5
p_death
dev.off()


## Figure 1C  total deaths in the 1st wave on the map#####
library(geojson);library(cartography);library(magick);library(geojsonio)

a <- data_combine[-(which(data_combine$Country == "United Republic of Tanzania"|
                            data_combine$Country == "Burundi"|
                            data_combine$Country == "Eritrea")),c(1,2,32,34)]

africa <- geojson_read("./Raw data/Africa1.geojson",what = "sp")
africa@data %<>% left_join(a, by=c("ISO_A3"="countryterritoryCode"))


breaks <- classIntervals(africa@data$cum_deaths_per_100k_1st, n = 8, style = "jenks", na.rm=T)$brks
breaks <- c(0,breaks)
breaks[2]<-0.000001
palblue <- brewer.pal(9, name = "Oranges")
palblue[1]<-"#FFFFFF"
#options(OutDec = "·")
png(filename = "./Results/Figures/Figure 1C cum_deaths_per100k_1stWAVEa.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "cum_deaths_per_100k_1st", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = "", legend.title.cex = 1.2,lwd = 2, ##Total deaths per 100K population \nin the second wave
           legend.values.cex = 1.1, legend.pos = c(-30,-35),legend.values.rnd=2)
points(-23.3, -31, pch = 16, col = 'white', cex = 2)
text(-24, -30, 'No death reported', adj = 0,cex = 1.1)
dev.off()

## Figure 1D  total deaths in the 1st wave on the map#####
breaks <- classIntervals(africa@data$cum_deaths_per_100k_2nd, n = 8, style = "jenks", na.rm=T)$brks
breaks <- c(0,breaks)
breaks[2]<-0.000001
palblue <- brewer.pal(9, name = "Oranges")
palblue[1]<-"#FFFFFF"
#options(OutDec = "·")
png(filename = "./Results/Figures/Figure 1D cum_deaths_per100k_2ndWAVE.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "cum_deaths_per_100k_2nd", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = "", legend.title.cex = 1.2,lwd = 2, ## Total deaths per 100K population \nin the second wave
           legend.values.cex = 1.1, legend.pos = c(-30,-35),legend.values.rnd=2) #legend.values.cex = 1
points(-23.3, -31, pch = 16, col = 'white', cex = 2)
text(-24, -30, 'No death reported', adj = 0,cex = 1.1)
dev.off()



#### Figure 2 realtionship between 1st wave and 2nd wave#####
data_1st_2nd <- data_combine[-which(data_combine$Country == 'United Republic of Tanzania'|
                                               data_combine$Country == "Burundi"|
                                               data_combine$Country == "Eritrea"|
                                               data_combine$Country == "Seychelles"),] ## 43 countries left


data_1st_2nd <- within(data_1st_2nd,{
  cat <- NA
  cat[Country=="São Tomé and Príncipe"  ] <- 'yes' #|country=="Seychelles"
  cat[is.na(cat)] <- 'no'
})


library(ggrepel)
data_1st_2nd$Country[data_1st_2nd$Country=="Democratic Republic of the Congo"] <- "DRC"
p<- ggplot(data_1st_2nd, aes(x=cum_deaths_per_100k_1st, y=cum_deaths_per_100k_2nd)) + 
  geom_point(aes(colour = cat),size = 3) +
  theme(legend.position = "none")+
  scale_colour_manual("legend", values = c("yes" = "#ffcccb", "no" = "#FF0000FF"))+
  geom_label_repel(aes(label=Country)) + # , vjust = 0, hjust = 0, nudge_x = 0, angle = 30
  #geom_text(aes(label=location),hjust=0.5, vjust=1.5)+
  scale_x_log10(limits = c(0.005,60))+
  scale_y_log10(limits = c(0.005,60))+
  # scale_x_continuous()+ 
  # scale_y_continuous()+ 
  theme(axis.text = element_text(face = "bold", size = 13, colour = "black")) +
  theme(panel.background = element_rect(fill = "white", colour = "grey5")) +
  theme(axis.title= element_text(size=18, face= "bold")) +
  xlab("Per 100K population mortality rate in the first wave") + ylab("Per 100K population mortality rate in the second wave")+
  theme(panel.grid.minor = element_blank(), panel.grid.major =   element_blank(),
        axis.line.y = element_blank(),
        axis.ticks.y = element_blank()) +
  geom_abline(intercept = 0, slope = 1,linetype = "dashed")

cairo_pdf('./Results/Figures/Figure 2 1st_2nd_mortality_scatter.pdf',width=10,height=10) #,family="Arial Unicode MS"#width=13,height=13
p
dev.off()

cor(data_1st_2nd$cum_deaths_per_100k_1st, data_1st_2nd$cum_deaths_per_100k_2nd) ## 0.788184

##  Extended Data Fig. 1#####
africa <- geojson_read("./Raw data/Africa1.geojson",what = "sp")

africa@data %<>% left_join(data_combine[,c(2:28)], by=c("ISO_A3"="countryterritoryCode"))

##pop####
breaks <- classIntervals(africa@data$pop, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"

png(filename = "./Results/Extended Data/Extended Data Fig. 2/1.Pop.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "pop", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA,legend.title.cex = 1,  ## legend.title.txt = "Population, total", 
           legend.values.cex = 1, legend.pos = c(-30,-35)) #,legend.values.rnd=3
dev.off()


##population density####
breaks <- classIntervals(africa@data$pop_den, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/2.Pop_den.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "pop_den", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue, legend.title.txt = NA, legend.title.cex = 1, ## legend.title.txt = "Population density [people per\nsq. km of land area]",lwd = 2,
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3) ## 
dev.off()


## urban pop######
breaks <- classIntervals(africa@data$urban_pop, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/3.Urban_pop.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "urban_pop", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt =NA, legend.title.cex = 1, ## legend.title.txt = "Urban population\n[% of total population]",lwd = 2,
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3) ## 
dev.off()


####### pop age 65######
breaks <- classIntervals(africa@data$Pop_65_age, n = 8, style = "jenks", na.rm=T)$brks

#breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/4.Pop_65_age.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "Pop_65_age", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, ## "Population ages 65 and above \n [% of total population]", lwd = 2,
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3) ## 
dev.off() 


############### sex##########
breaks <- classIntervals(africa@data$SEX, n = 6, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(7, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/5.SEX.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "SEX", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, ## "Sex ratio (Male:female)" lwd = 2,
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3) ## 
dev.off()


######GDP per capita#####
breaks <- classIntervals(africa@data$gdp_per_capita, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/6.Gdp_per_capita.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "gdp_per_capita", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, # "GDP per capita (current US$)"
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3) ## 
dev.off()

#####HDI#####
breaks <- classIntervals(africa@data$HDI, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/7.Hdi.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "HDI", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, ## "Human development index",lwd = 2,
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3)
dev.off()


########### airport ######
breaks <- classIntervals(africa@data$airport_no, n = 5, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(6, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/8.airport.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "airport_no", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, ## "International tourism, \n number of arrivals"
           legend.values.cex = 1, legend.pos = c(-30,-35))#,legend.values.rnd=1
dev.off()

##########airport seats#####
breaks <- classIntervals(africa@data$airport_seats, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/9.airport_seats.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "airport_seats", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, ## "International tourism, \n number of arrivals"
           legend.values.cex = 1, legend.pos = c(-30,-35))#,legend.values.rnd=1
dev.off()


############Current_expenditures_health######
breaks <- classIntervals(africa@data$Current_expenditures_health, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/10.Current_expenditures_health.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "Current_expenditures_health", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, ## "Current health expenditure \n (% of GDP)"
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3)
dev.off()

### load data on infectious disease vulnerable index#####
breaks <- classIntervals(africa@data$vulnerable_index, n = 7, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(8, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/11.vulnerable_index.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "vulnerable_index", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, ## vulnerable_index
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3)
dev.off()


#########disease burden from communicable diseases######
breaks <- classIntervals(africa@data$Burden_communicable, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/12.Burden_communicable.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "Burden_communicable", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, # "DALY rates per 100,000 individuals \n from non-communicable diseases"
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3)
dev.off()

##### Burden_non_communicable #####
breaks <- classIntervals(africa@data$Burden_non_communicable, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/13.Burden_non_communicable.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "Burden_non_communicable", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, # "DALY rates per 100,000 individuals\n from communicable, neonatal, \n maternal & nutritional diseases "
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=2)
dev.off()

######### HIV#######
breaks <- classIntervals(africa@data$Hiv, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/14.Hiv.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "Hiv", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, ## "Prevalence of HIV, total \n (% of population ages 15-49)"
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=1)
dev.off()


######### Diabetes######
breaks <- classIntervals(africa@data$Diabetes, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/15.Diabetes.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "Diabetes", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, # "Diabetes prevalence \n (% of population ages 20 to 79)"
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=1)
dev.off()

##### test capicity#####
png(filename = "./Results/Extended Data/Extended Data Fig. 2/16.test_capacity.png", width=1920, height=1240, pointsize = 22)
typoLayer(
  spdf= africa, 
  var="test_capacity",  
  col = (rev(brewer.pal(3,"RdYlBu"))), 
  #col = rev(brewer.pal(3, name = "Oranges")),
  colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
  legend.title.txt = NA,legend.values.cex = 1,legend.title.cex = 1,
  legend.pos = c(-30,-35),add = F)
dev.off()

##### readniness########
png(filename = "./Results/Extended Data/Extended Data Fig. 2/17.readniess.png", width=1920, height=1240, pointsize = 22)
typoLayer(
  spdf= africa, 
  var="readiness",  
  col = (rev(brewer.pal(4,"RdYlBu"))), 
  #col = rev(brewer.pal(4, name = "Oranges")),
  colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
  legend.values.order = c('adequate','moderate','limited'),
  legend.title.txt = NA,  legend.values.cex = 1,legend.title.cex = 1,
  legend.pos = c(-30,-35),add = F)
dev.off()

#### no of neighbours######

png(filename = "./Results/Extended Data/Extended Data Fig. 2/18.no_neighbour.png", width=1920, height=1240, pointsize = 22)
typoLayer(
  spdf= africa, 
  var="no_neighbour",  
  col = (rev(brewer.pal(11,"RdYlBu"))), 
  #col = rev(brewer.pal(4, name = "Oranges")),
  colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
  legend.values.order = c('0','1','2','3','4','5','6','7','8','9'),
  legend.title.txt = NA,legend.values.cex = 1,legend.title.cex = 1,
  legend.pos = c(-30,-35),add = F)
dev.off()


#### latitude####
breaks <- classIntervals(africa@data$lat, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
#options(OutDec = "·")
png(filename = "./Results/Extended Data/Extended Data Fig. 2/19.latitude.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "lat", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, # "Diabetes prevalence \n (% of population ages 20 to 79)"
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=2)
dev.off()

## under-reporting#####
breaks <- classIntervals(africa@data$ratio_expected_reported, n = 8, style = "jenks", na.rm=T)$brks
breaks[2] <- 1.8
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
#options(OutDec = "·")
png(filename = "./Results/Extended Data/Extended Data Fig. 2/20.reporting_ratio.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "ratio_expected_reported", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, # "Diabetes prevalence \n (% of population ages 20 to 79)"
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=2)
dev.off()

#### testing policy index####
breaks <- classIntervals(africa@data$test_policy_greater2_day, n = 8, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"

png(filename = "./Results/Extended Data/Extended Data Fig. 2/21.testing_policy.png", width=1920, height=1240, pointsize = 22)
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "test_policy_greater2_day", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, # "Diabetes prevalence \n (% of population ages 20 to 79)"
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=2)
dev.off()

## testing policy on November####
png(filename = "./Results/Extended Data/Extended Data Fig. 2/22.policy on 1101.png", width=1920, height=1240, pointsize = 22)
typoLayer(
  spdf= africa, 
  var="Testing_policy_1101",  
  col = (rev(brewer.pal(4,"RdYlBu"))), 
  #col = rev(brewer.pal(4, name = "Oranges")),
  colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
  legend.values.order = c('3','2','1'),
  legend.title.txt = "",  legend.values.cex = 1,legend.title.cex = 1, #Testing policy index on November 1st
  legend.pos = c(-30,-35),add = F)
dev.off()


#### test data quality index####
png(filename = "./Results/Extended Data/Extended Data Fig. 2/23.test_data_quality.png", width=1920, height=1240, pointsize = 22)

typoLayer(
  spdf= africa, 
  var="Source.Quality",  
  col = (rev(brewer.pal(4,"RdYlBu"))), 
  #col = rev(brewer.pal(3, name = "Oranges")),
  legend.values.order = c("good","satisfactory","basic","no data"),
  colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
  legend.title.txt = NA,legend.values.cex = 1,legend.title.cex = 1,
  legend.pos = c(-30,-35),add = F)
dev.off()


##### Tests per capita ########
breaks <- classIntervals(africa@data$Testing_ratio_100K, n = 8, style = "jenks", na.rm=T)$brks
png(filename = "./Results/Extended Data/Extended Data Fig. 2/24.test_per_capita.png", width=1920, height=1240, pointsize = 22)

# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(9, name = "Oranges")
#palblue[1]<-"#FFFFFF"
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "Testing_ratio_100K", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA,legend.title.cex = 1,  ## legend.title.txt = "Population, total", 
           legend.values.cex = 1, legend.pos = c(-30,-35)) #,legend.values.rnd=3
dev.off()



##### AUC all stringency#####
breaks <- classIntervals(africa@data$str_auc_all, n = 6, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(7, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/25.str_auc_all.png", width=1920, height=1240, pointsize = 22) 
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "str_auc_all", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, # "Diabetes prevalence \n (% of population ages 20 to 79)"
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3)
dev.off()

## strigency index when reach death rate threshold#####
breaks <- classIntervals(africa@data$str_cum_death_per100K_0.1, n = 6, style = "jenks", na.rm=T)$brks
# breaks <- c(0,breaks)
#breaks[2]<-1
palblue <- brewer.pal(7, name = "Oranges")
#palblue[1]<-"#FFFFFF"
png(filename = "./Results/Extended Data/Extended Data Fig. 2/26.str_threshold.png", width=1920, height=1240, pointsize = 22) 
#par(mar=c(0,0,0,0))
choroLayer(spdf = africa, var = "str_cum_death_per100K_0.1", colNA = "grey", legend.nodata = "Non WHO Afro country/No data",
           breaks=breaks, col=palblue,legend.title.txt = NA, legend.title.cex = 1, # "Diabetes prevalence \n (% of population ages 20 to 79)"
           legend.values.cex = 1, legend.pos = c(-30,-35),legend.values.rnd=3)
dev.off()

# Combine images
#Read images
image1 <- image_read("./Results/Extended Data/Extended Data Fig. 2/1.Pop.png")
image2 <- image_read("./Results/Extended Data/Extended Data Fig. 2/2.Pop_den.png")
image3 <- image_read("./Results/Extended Data/Extended Data Fig. 2/3.Urban_pop.png")
image4 <- image_read("./Results/Extended Data/Extended Data Fig. 2/4.Pop_65_age.png")
image5 <- image_read("./Results/Extended Data/Extended Data Fig. 2/5.SEX.png")
image6 <- image_read("./Results/Extended Data/Extended Data Fig. 2/6.Gdp_per_capita.png")
image7 <- image_read("./Results/Extended Data/Extended Data Fig. 2/7.Hdi.png")
image8 <- image_read("./Results/Extended Data/Extended Data Fig. 2/8.airport.png")
image9 <- image_read("./Results/Extended Data/Extended Data Fig. 2/9.airport_seats.png")
image10 <- image_read("./Results/Extended Data/Extended Data Fig. 2/10.Current_expenditures_health.png")
image11 <- image_read("./Results/Extended Data/Extended Data Fig. 2/11.vulnerable_index.png")
image12 <- image_read("./Results/Extended Data/Extended Data Fig. 2/12.Burden_communicable.png")
image13 <- image_read("./Results/Extended Data/Extended Data Fig. 2/13.Burden_non_communicable.png")
image14 <- image_read("./Results/Extended Data/Extended Data Fig. 2/14.Hiv.png")
image15 <- image_read("./Results/Extended Data/Extended Data Fig. 2/15.Diabetes.png")
image16 <- image_read("./Results/Extended Data/Extended Data Fig. 2/16.test_capacity.png")
image17 <- image_read("./Results/Extended Data/Extended Data Fig. 2/17.readniess.png")
image18 <- image_read("./Results/Extended Data/Extended Data Fig. 2/18.no_neighbour.png")
image19 <- image_read("./Results/Extended Data/Extended Data Fig. 2/19.latitude.png")
image20 <- image_read("./Results/Extended Data/Extended Data Fig. 2/20.reporting_ratio.png")
image21 <- image_read("./Results/Extended Data/Extended Data Fig. 2/21.testing_policy.png")
image22 <- image_read("./Results/Extended Data/Extended Data Fig. 2/22.policy on 1101.png")
image23 <- image_read("./Results/Extended Data/Extended Data Fig. 2/23.test_data_quality.png")
image24 <- image_read("./Results/Extended Data/Extended Data Fig. 2/24.test_per_capita.png")
image25 <- image_read("./Results/Extended Data/Extended Data Fig. 2/25.str_auc_all.png")
image26 <- image_read("./Results/Extended Data/Extended Data Fig. 2/26.str_threshold.png")


#Crop images
image1_crop <- image_crop(image1, "1080x960+420+140")
image2_crop <- image_crop(image2, "1080x960+420+140")
image3_crop <- image_crop(image3, "1080x960+420+140")
image4_crop <- image_crop(image4, "1080x960+420+140")
image5_crop <- image_crop(image5, "1080x960+420+140")
image6_crop <- image_crop(image6, "1080x960+420+140")
image7_crop <- image_crop(image7, "1080x960+420+140")
image8_crop <- image_crop(image8, "1080x960+420+140")
image9_crop <- image_crop(image9, "1080x960+420+140")
image10_crop <- image_crop(image10, "1080x960+420+140")
image11_crop <- image_crop(image11, "1080x960+420+140")
image12_crop <- image_crop(image12, "1080x960+420+140")
image13_crop <- image_crop(image13, "1080x960+420+140")
image14_crop <- image_crop(image14, "1080x960+420+140")
image15_crop <- image_crop(image15, "1080x960+420+140")
image16_crop <- image_crop(image16, "1080x960+420+140")
image17_crop <- image_crop(image17, "1080x960+420+140")
image18_crop <- image_crop(image18, "1080x960+420+140")
image19_crop <- image_crop(image19, "1080x960+420+140")
image20_crop <- image_crop(image20, "1080x960+420+140")
image21_crop <- image_crop(image21, "1080x960+420+140")
image22_crop <- image_crop(image22, "1080x960+420+140")
image23_crop <- image_crop(image23, "1080x960+420+140")
image24_crop <- image_crop(image24, "1080x960+420+140")
image25_crop <- image_crop(image25, "1080x960+420+140")
image26_crop <- image_crop(image26, "1080x960+420+140")

# Save as 3*2 plots image, and add titles for each map
png(file =  "./Results/Extended Data/Extended Data Fig. 1/combine1.png", width=1080*3, height=960*2, pointsize=22)
par(mai=rep(0.5,4)) # no margins
layout(matrix(1:6, ncol=3, byrow=TRUE))
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{A} Population, total"), cex.main = 2,adj = 0)
rasterImage(image1_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{B} Population density (people per sq. km of land area)"), cex.main = 2,adj = 0)
rasterImage(image2_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{C} Urban population (% of total population)"), cex.main = 2,adj = 0)
rasterImage(image3_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{D} Population ages 65 and above (% of total population)"), cex.main = 2,adj = 0)
rasterImage(image4_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{E} Sex ratio (Male/Female)"), cex.main = 2,adj = 0)
rasterImage(image5_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = expression(bold("F")~"GDP per capita (current US$)"), cex.main = 2,adj = 0) ## now showing $ latex2exp::TeX("\\textbf{F} GDP per capita (current US$)")
rasterImage(image6_crop, 0, 0, 1,1)
dev.off()

png(file =  "./Results/Extended Data/Extended Data Fig. 1/combine2.png", width=1080*3, height=960*2, pointsize=22)
par(mai=rep(0.5,4)) # no margins
layout(matrix(1:6, ncol=3, byrow=TRUE))
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{G} Human development index"), cex.main = 2,adj = 0)
rasterImage(image7_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{H} Number of international airports"), cex.main = 2,adj = 0)
rasterImage(image8_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{I} Volume of international air travel"), cex.main = 2,adj = 0)
rasterImage(image9_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{J} Current health expenditure (% of GDP)"), cex.main = 2,adj = 0)
rasterImage(image10_crop, 0, -0.05, 1,0.95)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{K} Infectious disease resilience index"), cex.main = 2,adj = 0)
rasterImage(image11_crop, 0, -0.05, 1,0.95)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i') #, main = "K DALY rates per 100,000 individuals from communicable,\nneonatal, maternal & nutritional diseases", cex.main = 2
title(expression(bold("L\n")~"DALY rates per 100,000 individuals from communicable,\nneonatal, maternal & nutritional diseases"), line = -1.2,cex.main = 2,adj = 0) #line = -1.1,
rasterImage(image12_crop, 0, -0.05, 1,0.95)
#text(0.025, 0.95,"neonatal, maternal & nutritional diseases", adj = 0,cex=2)
dev.off()


png(file =  "./Results/Extended Data/Extended Data Fig. 1/combine3.png", width=1080*3, height=960*2, pointsize=22)
par(mai=rep(0.5,4)) # no margins
layout(matrix(1:6, ncol=3, byrow=TRUE))
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i') #, main = "L DALY rates per 100,000 individuals from non-communicable \ndiseases", cex.main = 2
title(expression(bold("M\n")~"DALY rates per 100,000 individuals from non-communicable \ndiseases"), adj = 0, line = -1.2,cex.main = 2)
rasterImage(image13_crop, 0, -0.05, 1,0.95)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{N} Prevalence of HIV, total (% of population ages 15-49)"), cex.main = 2,adj = 0)
rasterImage(image14_crop, 0, -0.05, 1,0.95)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{O} Diabetes prevalence (% of population ages 20 to 79)"), cex.main = 2,adj = 0)
rasterImage(image15_crop, 0, -0.05, 1,0.95)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{P} COVID-19 test capacity"), cex.main = 2,adj = 0)
rasterImage(image16_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{Q} COVID-19 readiness status"), cex.main = 2,adj = 0)
rasterImage(image17_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{R} Number of borders"), cex.main = 2,adj = 0)
#title("\\textbf{Q} No. of neighbours", adj = 0.5, line = 0,cex.main = 2)
rasterImage(image18_crop, 0, 0, 1,1)
dev.off()


png(file =  "./Results/Extended Data/Extended Data Fig. 1/combine4.png", width=1080*3, height=960*2, pointsize=22)
par(mai=rep(0.5,4)) # no margins
layout(matrix(1:6, ncol=3, byrow=TRUE))
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{S} Latitude"), cex.main = 2,adj = 0)
#title("(R) Latitude", adj = 0.5, line = 0,cex.main = 2)
rasterImage(image19_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{T} Ratio of total COVID-19 mortality to reported COVID-19 mortality"), cex.main = 2,adj = 0)
rasterImage(image20_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{U} Days with testing policy index >= 2"), cex.main = 2,adj = 0)
rasterImage(image21_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{V} Testing policy index on 1st November 2020"), cex.main = 2,adj = 0)
rasterImage(image22_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{W} Test data quality"), cex.main = 2,adj = 0)
rasterImage(image23_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{X} Total number of tests per 100K population as of 31 Dec. 2020"), cex.main = 2,adj = 0)
rasterImage(image24_crop, 0, 0, 1,1)
dev.off()


png(file =  "./Results/Extended Data/Extended Data Fig. 1/combine5.png", width=1080*3, height=960*2, pointsize=22)
par(mai=rep(0.5,4)) # no margins
layout(matrix(1:6, ncol=3, byrow=TRUE))
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{Y} AUC of  stringency index"), cex.main = 2,adj = 0)
rasterImage(image25_crop, 0, 0, 1,1)
plot(NA, xlim=0:1, ylim=0:1, bty="n", axes=0, xaxs = 'i', yaxs='i', main = latex2exp::TeX("\\textbf{Z} Stringency index when cumulative deaths reached 0.1 per 100K population"), cex.main = 2,adj = 0)
rasterImage(image26_crop, 0, 0, 1,1)
dev.off()


