library(splines)
library(Epi)
library(glmnet)
library(WriteXLS)
library(tidyverse)
library(reshape)
library(mgcv)
library(MASS)
require(MESS)
library(dplyr)
library(reshape)
#library(reshape2)
#library(ggplot2)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##load data_for_analysing_1stCASE.RData#######
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
load("./R data/data_for_analysing_1stCASE.RData")
data_analysis_fixed$pop_log <- log(data_analysis_fixed$popsize)

## Considering the underreporting rate
#data_analysis_fixed2$off_value <- log(data_analysis_fixed2$popsize / (data_analysis_fixed2$ratio))
data_analysis_fixed$cum_deaths_predicted_1st <- as.integer(data_analysis_fixed$cum_deaths_1st * data_analysis_fixed$ratio_expected_reported)

save(data_analysis_fixed,
     file="./R data/data_for_analysing_mortality_1stWAVE.RData")

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## Univariable model ####
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
library(lme4)
## remove outliers or countries with missing predictors
data_analysis_fixed2 <- data_analysis_fixed[-which(data_analysis_fixed$countryterritoryCode=="ERI"|
                                                     data_analysis_fixed$countryterritoryCode=="BDI"|
                                                     data_analysis_fixed$countryterritoryCode=="TZA"|
                                                     data_analysis_fixed$Hiv==999),]



## using cum_deaths_predicted_1st as the outcome
hr <- lapply(c("pop_den", "urban_pop" , 
               "Pop_65_age", "SEX",
               'gdp_per_capita', "HDI" , 
               'airport_no',"airport_seats",
               "Current_expenditures_health" ,
               "vulnerable_index",
               "Burden_communicable" ,
               "Burden_non_communicable" ,
               "Hiv" ,"Diabetes",
               'test_capacity', "readiness",
               'no_neighbour_cat','lat'), 
             function(var) {
               formula <- as.formula(paste("cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) +  ", var))
               po <- glmer(formula, data_analysis_fixed2,family = poisson)  
               coef(summary(po)) #cbind(exp(cbind(RR = coef(summary(po))[,1], confint(po)[-1,])),coef(summary(po))[,4])
             })


hr <- lapply(hr,function(x) x <- cbind(x,rownames(x)))
cc<- as.data.frame(do.call("rbind", hr))
cc[,1:4] <- apply(cc[,1:4],2,as.numeric)
cc <- cc[,-c(3,6,7)]
names(cc) <- c("Coefficient","SD","p","var") # names(cc) <- c("RR","Lower","Upper",'p',"var")


cc0 <- cc[!grepl("(Intercept)", cc$var),]

cc0$RR <- exp(cc0$Coefficient)
cc0$Lower <- exp(cc0$Coefficient -1.96*cc0$SD)
cc0$Upper <- exp(cc0$Coefficient +1.96*cc0$SD)

#### For result presentation###
variableall <- rep(c("Population density [people per sq. km of land area]",
                     "Urban population [% of total population]" ,
                     "Population ages 65 and above [% of total population]",
                     'Sex ratio (Male/Female)',
                     "GDP per capita [current US$]" ,
                     "Human development index" ,  
                     "Number of international airports", 
                     "Volume international air travel",
                     "Current health expenditure [% of GDP]",
                     'Infectious disease resilience index',
                     "DALY rates per 100,000 individuals from communicable, neonatal, maternal & nutritional diseases",
                     "DALY rates per 100,000 individuals from non-communicable diseases",
                     "Prevalence of HIV, total (% of population ages 15-49)" ,
                     "Diabetes prevalence (% of population ages 20 to 79)", 
                     'COVID-19 test capacity',"COVID-19 readiness status",
                     'Number of borders, above 0',
                     'Latitude'), each=1)

Group1 <- rep(c('Demographics'),times=4)
Group2 <- rep(c('Socioeconomic'),times=2)
Group3 <- rep(c('Travel'),times=2)
Group4 <- rep(c('Health care'),times=2)
Group5 <- rep(c('Readiness'),times=2)
Group6 <- rep(c('Geography'),times=2)
Group7 <- rep(c('Co-morbidities'),times=4)
Groupall <- c(Group1,Group2,Group3,Group4,Group7,Group5,Group6)


cc0$variable <- variableall
cc0$group <- Groupall
cc0 <-cc0 %>%
  arrange(factor(group, levels = factor(c('Demographics','Socioeconomic','Travel','Health care','Co-morbidities','Environment','Readiness','Situation in nearby countries','Interventions'))))
cc0[,c(3,5,6,7)] <- round(cc0[,c(3,5,6,7)],digits = 3)
cc0$RR2 <- paste0(as.character(cc0$RR), ' (',as.character(cc0$Lower) ,'-',as.character(cc0$Upper),')')


####Multivariable model ######
library(AICcmodavg)

## using predicted cum_deaths_predicted_1st as the outcome, same as 1/ratio as the offset
po <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) +  
              pop_den + urban_pop + gdp_per_capita +
              airport_seats + 
              vulnerable_index + Burden_communicable+ 
              Hiv + lat, data_analysis_fixed2,family = poisson) #   remove  HDI +
## choose variables with p values smaller than 0.2 and remove variables with correlation r >0.6 (listed below)
# HDI and vulnerable, HDI and communicable, HDI and GDP per capita, 
# Communicable and non-communicable, population and airport seats

summary(po) 
AIC(po)# 629.0509
AICc(po) #636.1476

### Best multivarialbe model, by removing variables with larger p value#####
po1 <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) + 
               urban_pop + airport_seats + Hiv, data_analysis_fixed2,family = poisson) 

summary(po1)
AIC(po1) ##  623.2754
AICc(po1) ##624.9421

multi_AIC <- data.frame(coef(summary(po1)))
multi_AIC$var <- rownames(multi_AIC)
multi_AIC <- multi_AIC[,-3]
names(multi_AIC) <- c("Coefficient","SD","p","var") 

multi_AIC <- multi_AIC[!grepl("(Intercept)", multi_AIC$var),]

multi_AIC$RR <- exp(multi_AIC$Coefficient)
multi_AIC$Lower <- exp(multi_AIC$Coefficient -1.96*multi_AIC$SD)
multi_AIC$Upper <- exp(multi_AIC$Coefficient +1.96*multi_AIC$SD)
multi_AIC[,c(3,5,6,7)] <- round(multi_AIC[,c(3,5,6,7)],digits = 3)
multi_AIC$RR3 <- paste0(as.character(multi_AIC$RR), ' (',as.character(multi_AIC$Lower) ,'-',as.character(multi_AIC$Upper),')')


##  Exporeing other models with small AICc##
## 2nd minimum AICc
po2 <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) + 
               urban_pop + airport_seats  +lat, data_analysis_fixed2,family = poisson) 
summary(po2)
AIC(po2) ##623.6145
AICc(po2) ## 625.2811

## 3rd minimum AICc
po3 <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) +
               urban_pop + airport_seats  + Hiv + lat , data_analysis_fixed2,family = poisson)
summary(po3)
AIC(po3) ##623.0393
AICc(po3) ##625.4393

## 4th minimum AICc
po4 <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) +
               urban_pop +  Hiv + lat, data_analysis_fixed2,family = poisson)
summary(po4)
AIC(po4) ##624.9947
AICc(po4) ##626.6613

## 5th minimum AICc
po5 <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) +
               urban_pop + airport_seats  + Hiv + pop_den, data_analysis_fixed2,family = poisson)
summary(po5)
AIC(po5) ##624.5176
AICc(po5) ##626.9176


## Supplementary table 3 P1 exported####
## combine univariable and the best multivariable model
uni_multi <-left_join(cc0[,c(9,8,10,4)],multi_AIC[,c(8,4)])
uni_multi <- uni_multi[,-4]
WriteXLS(x=c('cc0','multi_AIC','uni_multi'), ExcelFileName = './Results/Tables/Supplementary table 3 P1 uni_multi_1stWAVE_mortality.xlsx',  
         verbose = FALSE, row.names = T, col.names = TRUE,
         na = "",envir = parent.frame())
 
### Figure 4######
# Add header as test/label##
library(ggplot2)
library(gridExtra)

unique(cc0$group)

gn <- c("",'Demographics', 'Socioeconomic', 'Travel', 'Health care','Co-morbidities', 
        'Readiness', 'Geography')

lab0 <- data.frame(v1=rep(c(43,41,33,
                            29,25,
                            19.5,8,4),1),
                   v2=rep(c(1),each=8),
                   v3=c(gn))

data_table0 <- ggplot(lab0, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4, hjust=0, vjust=0.5,lineheight = .8) + 
  annotate("text", label = "Category", x = 1, y = 43, hjust=0,vjust=0, fontface = "bold") +
  # annotate("text", label = "Subgroup", x = 1.75, y = 88, hjust=0,vjust=0.5, fontface = "bold") +
  xlim(1,2.5) +
  theme_bw() +
  #geom_hline(yintercept=c(20.5,21.5)) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(0.6,0,2.3,0.2), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table0
#grid.arrange(data_table0,data_table, ncol=2) #15 10


unique(cc0$variable)

gr <- c("", "Population density (people per sq. km of land area)", 
        "Urban population (% of total population)",                                                   
        #"Refugee population by country or territory of origin",                                                               
        "Population ages 65 and above (% of total population)" , "Sex ratio (Male/Female)",                                                                       
        "GDP per capita (current US$)", "Human development index" , 
        "Number of international airports", "Volume of international air travel", #Total seats in 
        #"International tourism, number of arrivals" ,# "Physicians (per 1,000 people)"  ,                                                                     
        "Current health expenditure (% of GDP)", 
        "Infectious disease resilience index",
        "DALY rates per 100,000 individuals from communicable,\nneonatal, maternal & nutritional diseases"  ,        
        "DALY rates per 100,000 individuals from non-communicable \ndiseases" , 
        "Prevalence of HIV, total (% of population ages 15-49)" ,"Diabetes prevalence (% of population ages 20-79)" ,
        "COVID-19 test capacity, yes" , "COVID-19 readiness status, adequate","Number of borders, above 0","Latitude") #neighbours


lab <- data.frame(v1=rep(c(43,41,39, 
                           37,35,33,
                           31,
                           29,27,25,23,
                           19.5,15.5,
                           12,10,8,6,4,2),1),
                  v2=rep(c(1),each=19),
                  v3=c(gr))


data_table <- ggplot(lab, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4, hjust=0, vjust=0.5,lineheight = .8) + 
  annotate("text", label = "Variable", x = 1, y = 43, hjust=0,vjust=0, fontface = "bold") +
  # annotate("text", label = "Subgroup", x = 1.75, y = 88, hjust=0,vjust=0.5, fontface = "bold") +
  xlim(1,2.5) +
  theme_bw() +
  #geom_hline(yintercept=c(20.5,21.5)) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(0.5,0,1,0.2), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table


## Univariable model
cc0 <- within(cc0,{
  index <- NA
  index[p >= 0.05] <- 'black'
  index[Lower >= 1 & p < 0.05] <- 'red'
  index[Upper <= 1 & p < 0.05] <- 'blue'
})

cc0$RR
cc0$Lower
cc0$Upper
cc0$index

dat <- data.frame(group = c(41,39, 
                            37,35,33,
                            31,
                            29,27,25,23,
                            19.5,15.5,
                            12,10,8,6,4,2),
                  cen = c(0.751,1.626,1.192,1.171,1.520,1.552,1.135,1.395,1.026,1.653,0.760,0.908,1.397,1.052,0.812,1.239,0.840,1.467),
                  low = c(0.546,1.221,0.859,0.866,1.054,1.144,0.835,1.050,0.752,1.247,0.556,0.668,1.044,0.766,0.424,0.508,0.288,1.092),
                  high = c(1.032,2.167,1.654,1.582,2.192,2.105,1.543,1.855,1.399,2.192,1.039,1.233,1.870,1.444,1.557,3.019,2.456,1.970),
                  index = c("black","red","black","black","red","red","black","red","black","red","black","black","red","black","black","black","black","red" ))

df <- data.frame(x1 = 1, x2 = 1, y1 = 2, y2 = 42)
#options(OutDec = "·")
p <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c("black", "red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.15) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "Univariable", x = 1, y = 43, vjust=0,hjust=0.5, fontface = "bold") +
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Risk Ratio", y="") + 
  scale_x_log10()+
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0.5,0.5,0.1), "lines"))+
  theme(legend.position = "none")
p


## multivariable 
multi_AIC <- within(multi_AIC,{
  index <- NA
  index[p >= 0.05] <- 'black'
  index[Lower >= 1 & p < 0.05] <- 'red'
  index[Upper <= 1 & p < 0.05] <- 'blue'
})

multi_AIC$RR
multi_AIC$Lower
multi_AIC$Upper
multi_AIC$index
multi_AIC$var


dat <- data.frame(group = c(41,39, 
                            37,35,33,
                            31,
                            29,27,25,23,
                            19.5,15.5,
                            12,10,8,6,4,2),
                  cen = c("",1.607,"","","","","",1.314,"","","","",1.402,"","","","",""),
                  low = c("",1.252,"","","","","",1.040,"","","","",1.104,"","","","",""),
                  high = c("",2.063,"","","","","",1.660,"","","","",1.780,"","","","",""),
                  index = c("","red","","","","","","red","","","","","red","","",'',"",""))
dat <- dat %>%
  mutate_at(c('cen','low','high','index'),as.character) %>% 
  mutate_at(c('cen','low','high'),as.numeric)
dat <- dat[complete.cases(dat),]

df <- data.frame(x1 = 1, x2 = 1, y1 = 2, y2 = 42)
p1 <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c("red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.15) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "Multivariable (AICc=624.94)", x = 1, y = 43,vjust=0,hjust=0.5, fontface = "bold") + #(AICc=550·54)
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Risk Ratio", y="") + 
  scale_x_log10(limits = c(0.5,3.0), breaks = c(0.5,1.0,2.0))+
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0,0.5,0), "lines"))+
  theme(legend.position = "none")
p1


library(Cairo)
cairo_pdf('./Results/Figures/Figure 4 glmm_uni_multi.pdf',width=12.5,height=6.5) #,family="Arial Unicode MS"
grid.arrange(data_table0,data_table, p,p1, ncol=4, widths = c(1.5,4.5,3,3))
dev.off()
