library(reshape); library(tidyverse);library(readxl)
library(ggplot2); library(dplyr); library(rdrop2); library(Rmisc); library(lubridate)
library(shiny); library(rsconnect);  library(plotly);library(yarrr)
library(knitr);library(RColorBrewer);library(utils);library(httr);library(magrittr)
library(sf);library(classInt);library(geojson);library(cartography);library(magick);library(geojsonio)
library(tinytex); library(gridExtra);library(scales);library(grid);library(pheatmap)
library(sp); library(spdep); require(MESS)
library(splines);library(Epi);library(glmnet);library(WriteXLS)
library(reshape2);library(mgcv);library(MASS)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## read data for outcomes####
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
WHOcountry<-
  read.csv('./Raw data/WHO_country_list.csv', stringsAsFactors = FALSE)[,-5] %>%
  dplyr::rename(popsize = pop)

## Download data from https://covid19.who.int/table and read it in
data <- 
  read.csv('./Raw data/case data/2021-03-26/WHO-COVID-19-global-data.csv', stringsAsFactors = FALSE) %>%
  mutate(Date_reported=as.Date(Date_reported, format = "%Y-%m-%d"))

## Extract data for WHO AFRO
africa_data <- 
  data[which(data$WHO_region == 'AFRO'& !(data$Country == "Réunion") & !(data$Country == "Mayotte")),] %>%## we didn't include the two territories before
  dplyr::select(.,c(1,3,6,8))%>%
  dplyr::rename("date"="Date_reported",
                'country'="Country",
                'cum_cases'="Cumulative_cases" ,
                "cum_deaths"="Cumulative_deaths")

## calculate rates
WHO_cases_and_deaths<- africa_data %>% 
  mutate_at('country', ~replace(., .=="Côte d’Ivoire" , "Cote d'Ivoire"))%>% 
  # revert back to per day deaths / cases
  group_by(country) %>%
  mutate(cum_cases=as.integer(cum_cases),cum_deaths=as.integer(cum_deaths),cases = as.integer(c(0,diff(cum_cases))), deaths = as.integer(c(0,diff(cum_deaths)))) %>%
  ungroup() %>%
  # convert to per 10k pop
  inner_join(WHOcountry %>% 
               dplyr::select(country,popsize,countryterritoryCode)) %>% 
  mutate(popsize = popsize / 100000,cum_cases_per_100k=cum_cases / popsize,cum_deaths_per_100k=cum_deaths / popsize,cases_per_100k=cases / popsize,deaths_per_100k=deaths / popsize)

## Date of the first case####
data_start <-
  filter(WHO_cases_and_deaths[,c(1,3,8)],cum_cases>0) %>% 
  group_by(countryterritoryCode) %>% 
  filter(row_number()==1)
names(data_start)[1] <- "first_case"

## Date of the first death####
data_start_death <-
  filter(WHO_cases_and_deaths[,c(1,4,8)],cum_deaths>0) %>% 
  group_by(countryterritoryCode) %>% 
  filter(row_number()==1)

names(data_start_death)[1] <- "first_death"


## Total deaths in the first and second waves ####
## get the end date of the first and second waves ######
new_death <- WHO_cases_and_deaths[,c(1,2,6)]
new_death <- spread(new_death,country,deaths)
new_death$sum <- rowSums(new_death[,2:48])
smoothCounts1 <-ksmooth(new_death$date,new_death$sum,kernel="normal",bandwidth=21,n.points = length(new_death$date))
dsmooth1 <-diff(smoothCounts1$y)
locmin1 <-sign(c(0,dsmooth1))<0 & sign(c(dsmooth1,0))>0
points1 <- data.frame(x=smoothCounts1$x[locmin1],y=smoothCounts1$y[locmin1]) ## '2020-10-31' and 2021-03-14' as of the end of the 1st and 2nd waves. 2020-09-26 was before the end of 1st case trough so ignored


## get total death 2nd wave#####
total_death_percap_1st <- WHO_cases_and_deaths[WHO_cases_and_deaths$date == as.Date('2020-10-31'),c(1,2,4,8,10)]
names(total_death_percap_1st)[c(3,5)] <- c("cum_deaths_1st","cum_deaths_per_100k_1st")
total_death_percap_all <- WHO_cases_and_deaths[WHO_cases_and_deaths$date == as.Date('2021-03-14'),c(1,2,4,8,10)]

total_death_percap <- left_join(total_death_percap_1st[,-1],total_death_percap_all[,-1])
total_death_percap$cum_deaths_per_100k_2nd <- total_death_percap$cum_deaths_per_100k - total_death_percap$cum_deaths_per_100k_1st
total_death_percap$cum_deaths_2nd <- total_death_percap$cum_deaths - total_death_percap$cum_deaths_1st
names(total_death_percap)[3] <- "countryterritoryCode"

outcome_list <- 
  data_start[,c(3,1)]%>%
  left_join(data_start_death[,-2])%>%
  left_join(total_death_percap[,c(3, 2,4,8,7)])
####~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
####~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

## read WHO country list, for choosing data for WHO African countries
WHOcountry <- read.csv("./Raw data/WHO_country_list.csv",  stringsAsFactors = F)[,c(5,1)] #header = T, sep = ",", quote = '"',fill = T

## read the raw data for predictors ######
## 1. Population from the World Bank, Eritrea using 2011 data, others using 2018####
pop <- read.csv('./Raw data/Variables/Population count/API_SP.POP.TOTL_DS2_en_csv_v2_988606.csv', skip = 3, header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(pop)[2]<- names(WHOcountry)[2]
pop0 <- left_join(WHOcountry,pop[,-1],by = "countryterritoryCode")
pop1 <- pop0[,-c(1,3,4)]
pop1 <- melt(pop1,id='countryterritoryCode')
pop1$variable  <- gsub('\\D','', pop1$variable) 

a <- pop1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

pop2 <- left_join(pop0[,c(1,2)],a0,by = "countryterritoryCode")
names(pop2)[3:4] <- c('year','pop') # Eritrea using 2011 data, others using 2018 data

##2. population density from the World bank####
pop_den <- read.csv('./Raw data/Variables/Population density/API_EN.POP.DNST_DS2_en_csv_v2_936296.csv', skip = 3, header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(pop_den)[2]<- names(WHOcountry)[2]
pop_den0 <- left_join(WHOcountry,pop_den[,-1],by = "countryterritoryCode")
pop_den1 <- pop_den0[,-c(1,3,4)]
pop_den1 <- melt(pop_den1,id='countryterritoryCode')
pop_den1$variable  <- gsub('\\D','', pop_den1$variable) 

a <- pop_den1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

pop_den2 <- left_join(pop_den0[,c(1,2)],a0,by = "countryterritoryCode")
names(pop_den2)[3:4] <- c('year','pop_den') # Eritrea using 2011 data others using 2018 data, and the south sudan is missing
# add south Sudan manually
pop_den2$pop_den[pop_den2$Country=='South Sudan'] <- 10975920/619745

## 3. urban pop######
urban_pop <- read.csv('./Raw data/Variables/Urban pop/API_SP.URB.TOTL.IN.ZS_DS2_en_csv_v2_936381.csv', skip = 3, header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(urban_pop)[2]<- names(WHOcountry)[2]
urban_pop0 <- left_join(WHOcountry,urban_pop[,-1],by = "countryterritoryCode")
urban_pop1 <- urban_pop0[,-c(1,3,4)]
urban_pop1 <- melt(urban_pop1,id='countryterritoryCode')
urban_pop1$variable  <- gsub('\\D','', urban_pop1$variable) 

a <- urban_pop1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

urban_pop2 <- left_join(urban_pop0[,c(1,2)],a0,by = "countryterritoryCode")
names(urban_pop2)[3:4] <- c('year','urban_pop') #Eritrea using 2011 data, others using 2018 data

####### 4. pop age 65######
Pop_65_age <- read.csv('./Raw data/Variables/Pop age 65/API_SP.POP.65UP.TO.ZS_DS2_en_csv_v2_988979.csv', skip = 3, header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(Pop_65_age)[2]<- names(WHOcountry)[2]
Pop_65_age0 <- left_join(WHOcountry,Pop_65_age[,-1],by = "countryterritoryCode")
Pop_65_age1 <- Pop_65_age0[,-c(1,3,4)]
Pop_65_age1 <- melt(Pop_65_age1,id='countryterritoryCode')
Pop_65_age1$variable  <- gsub('\\D','', Pop_65_age1$variable) 

a <- Pop_65_age1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

Pop_65_age2 <- left_join(Pop_65_age0[,c(1,2)],a0,by = "countryterritoryCode")
names(Pop_65_age2)[3:4] <- c('year','Pop_65_age')  # Eritrea using 2011 data, others using 2018 data

###########5. sex ratio##########
SEX<- read.csv('./Raw data/Variables/Sex/API_SP.POP.TOTL.FE.ZS_DS2_en_csv_v2_1070167.csv', skip = 3, header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(SEX)[2]<- names(WHOcountry)[2]
SEX0 <- left_join(WHOcountry,SEX[,-1],by = "countryterritoryCode")
SEX1 <- SEX0[,-c(1,3,4)]
SEX1 <- melt(SEX1,id='countryterritoryCode')
SEX1$variable  <- gsub('\\D','', SEX1$variable) 

a <- SEX1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

SEX2 <- left_join(SEX0[,c(1,2)],a0,by = "countryterritoryCode")
names(SEX2)[3:4] <- c('year','SEX')
#nrow(SEX2[is.na(SEX2$SEX),])
SEX2$SEX <- (100-SEX2$SEX)/SEX2$SEX # Eritrea using 2011 data, others using 2018 data


######6. GDP per capita#####
gdp_per_capita <- read.csv('./Raw data/Variables/GDP per capita/API_NY.GDP.PCAP.CD_DS2_en_csv_v2_935987.csv', skip = 3, header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(gdp_per_capita)[2]<- names(WHOcountry)[2]
gdp_per_capita0 <- left_join(WHOcountry,gdp_per_capita[,-1],by = "countryterritoryCode")
gdp_per_capita1 <- gdp_per_capita0[,-c(1,3,4)]
gdp_per_capita1 <- melt(gdp_per_capita1,id='countryterritoryCode')
gdp_per_capita1$variable  <- gsub('\\D','', gdp_per_capita1$variable) 

a <- gdp_per_capita1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

gdp_per_capita2 <- left_join(gdp_per_capita0[,c(1,2)],a0,by = "countryterritoryCode")
names(gdp_per_capita2)[3:4] <- c('year','gdp_per_capita') #Eritrea using 2011 data, South Sudan using 2015 data, others using 2018 data


#####7. HDI#####
hdi <- read.csv('./Raw data/Variables/HDI/Human Development Index (HDI).csv', skip = 1, header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(hdi)[2] <- 'Country'

# Match country names: Cape Verde, Côte d’Ivoire, Democratic Republic of the Congo, Eswatini, Guinea Bissau, United Republic of Tanzania
hdi$Country[hdi$Country=='Tanzania (United Republic of)'] <-'United Republic of Tanzania'
hdi$Country[hdi$Country=='Cabo Verde'] <-'Cape Verde'
hdi$Country[hdi$Country=="Côte d'Ivoire"] <- "Côte d’Ivoire" 
hdi$Country[hdi$Country=="Sao Tome and Principe"] <- "São Tomé and Príncipe"
hdi$Country[hdi$Country=="Congo (Democratic Republic of the)"] <-"Democratic Republic of the Congo"
hdi$Country[hdi$Country=="Eswatini (Kingdom of)"] <-"Eswatini"
hdi$Country[hdi$Country=="Guinea-Bissau"] <-"Guinea Bissau"

hdi1 <- left_join(WHOcountry,hdi,by = "Country")
hdi2 <- hdi1[,c(1,2,60)]
hdi2$year <- 2018
hdi2 <- hdi2[,c(1,2,4,3)]
names(hdi2)[4] <- 'HDI'
hdi2$HDI <- as.numeric(hdi2$HDI) ##all using 2018

########### 8. airport ######
airport <- read.csv('./Raw data/Variables/airport/airport_volume_airport_locations.csv',  header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
unique(airport$Country.Name) 
airport$Country.Name[airport$Country.Name == 'Sao Tome and Principe'] <- "São Tomé and Príncipe"
airport$Country.Name[airport$Country.Name == 'Tanzania'] <- "United Republic of Tanzania"
airport$Country.Name[airport$Country.Name == 'Swaziland'] <- "Eswatini"
airport$Country.Name[airport$Country.Name == "Ivory Coast (Cote d'Ivoire)"] <- "Côte d’Ivoire"

airport_africa  <- airport %>% filter(Country.Name %in% WHOcountry$Country)
unique(airport_africa$Country.Name) # #no missing data
airport_africa$index <- 1

airport_africa_no <- airport_africa%>% 
  group_by(Country.Name) %>% 
  summarise(airport_no = sum(index))

names(airport_africa_no)[1]<- names(WHOcountry)[1]
airport_africa_no0 <- left_join(WHOcountry[,-3],airport_africa_no)
airport_africa_no1 <- airport_africa_no0[,-1]


##########9. airport seats#####
airport_africa_seats <- airport_africa%>% 
  group_by(Country.Name) %>% 
  summarise(airport_seats = sum(TotalSeats))

names(airport_africa_seats)[1]<- names(WHOcountry)[1]
airport_africa_seats0 <- left_join(WHOcountry[,-3],airport_africa_seats)
airport_africa_seats1 <- airport_africa_seats0[,-1]

############10. Current_expenditures_health######
Current_expenditures_health <- read.csv('./Raw data/Variables/Current health expenditure/API_SH.XPD.CHEX.GD.ZS_DS2_en_csv_v2_989101.csv', skip = 3, header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(Current_expenditures_health)[2]<- names(WHOcountry)[2]
Current_expenditures_health0 <- left_join(WHOcountry,Current_expenditures_health[,-1],by = "countryterritoryCode")
Current_expenditures_health1 <- Current_expenditures_health0[,-c(1,3,4)]
Current_expenditures_health1 <- melt(Current_expenditures_health1,id='countryterritoryCode')
Current_expenditures_health1$variable  <- gsub('\\D','', Current_expenditures_health1$variable) 

a <- Current_expenditures_health1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

Current_expenditures_health2 <- left_join(Current_expenditures_health0[,c(1,2)],a0,by = "countryterritoryCode")
names(Current_expenditures_health2)[3:4] <- c('year','Current_expenditures_health') # data of 2017, no missing

### 11. infectious disease vulnerable index, but we call it resilience. Because the larger of the value, the more resilient.#####
vulnerable<- read_excel('./Raw data/Variables/infectious disease vulnerable/ID vulnerable index.xlsx')
names(vulnerable)[4] <- 'vulnerable_index'
vulnerable <- vulnerable[vulnerable$WHO==1,]


#########12. communicable diseases burden ######
Burden_communicable<- read.csv('./Raw data/Variables/Disease_burden/burden-of-disease-rates-from-communicable-neonatal-maternal-nutritional-diseases.csv', header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(Burden_communicable)[2]<- names(WHOcountry)[2]
Burden_communicable0  <- Burden_communicable %>% filter(countryterritoryCode %in% WHOcountry$countryterritoryCode)
Burden_communicable1 <- Burden_communicable0[,-1]
names(Burden_communicable1)[2:3] <- c('variable','value')

a <- Burden_communicable1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

Burden_communicable2 <- left_join(unique(Burden_communicable0[,c(1,2)]),a0,by = "countryterritoryCode")
names(Burden_communicable2)[c(1,3:4)] <- c('country','year','Burden_communicable')
#nrow(Burden_communicable2[is.na(Burden_communicable2$Burden_communicable),])

##### 13. Burden_non_communicable #####
Burden_non_communicable<- read.csv('./Raw data/Variables/Disease_burden/burden-of-disease-rates-from-ncds.csv', header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(Burden_non_communicable)[2]<- names(WHOcountry)[2]
Burden_non_communicable0  <- Burden_non_communicable %>% filter(countryterritoryCode %in% WHOcountry$countryterritoryCode)
Burden_non_communicable1 <- Burden_non_communicable0[,-1]
names(Burden_non_communicable1)[2:3] <- c('variable','value')

a <- Burden_non_communicable1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

Burden_non_communicable2 <- left_join(unique(Burden_non_communicable0[,c(1,2)]),a0,by = "countryterritoryCode")
names(Burden_non_communicable2)[c(1,3:4)] <- c('country','year','Burden_non_communicable')
#nrow(Burden_non_communicable2[is.na(Burden_non_communicable2$Burden_non_communicable),])

#########14. HIV#######
Hiv<- read.csv('./Raw data/Variables/HIV/API_SH.DYN.AIDS.ZS_DS2_en_csv_v2_1068894.csv', skip = 3, header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(Hiv)[2]<- names(WHOcountry)[2]
Hiv0 <- left_join(WHOcountry,Hiv[,-1],by = "countryterritoryCode")
Hiv1 <- Hiv0[,-c(1,3,4)]
Hiv1 <- melt(Hiv1,id='countryterritoryCode')
Hiv1$variable  <- gsub('\\D','', Hiv1$variable) 

a <- Hiv1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

Hiv2 <- left_join(Hiv0[,c(1,2)],a0,by = "countryterritoryCode")
names(Hiv2)[3:4] <- c('year','Hiv')
#nrow(Hiv2[is.na(Hiv2$Hiv),]) ## two countries (Seychelles, São Tomé and Príncipe) were missing

######### 15.Diabetes######
Diabetes<- read.csv('./Raw data/Variables/Diabetes/API_SH.STA.DIAB.ZS_DS2_en_csv_v2_1074434.csv', skip = 3, header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)
names(Diabetes)[2]<- names(WHOcountry)[2]
Diabetes0 <- left_join(WHOcountry[,-3],Diabetes[,-1],by = "countryterritoryCode")
Diabetes1 <- Diabetes0[,-c(1,3,4)]
Diabetes1 <- melt(Diabetes1,id='countryterritoryCode')
Diabetes1$variable  <- gsub('\\D','', Diabetes1$variable) 

a <- Diabetes1
a <- a[which(!is.na(a$value)),]

a0 <-
  a %>%
  group_by(countryterritoryCode) %>%
  arrange(countryterritoryCode,variable)%>%
  filter(row_number()==n())

Diabetes2 <- left_join(Diabetes0[,c(1,2)],a0,by = "countryterritoryCode")
names(Diabetes2)[3:4] <- c('year','Diabetes')
#nrow(Diabetes2[is.na(Diabetes2$Diabetes),])


##### 16. test capicity, 17. readniness#############
readiness<- 
  read_excel('./Raw data/Variables/lockdown and capacity.xlsx', sheet = 'readiness')


#### 18. no of neighbours######
africa <- geojson_read("./Raw data/Africa1.geojson",what = "sp")
nb <- poly2nb(africa, queen=TRUE)

nb.data  <- data.frame(map_dfr(nb, ~as_data_frame(t(.))))
nb.data <- 
  nb.data %>%
  mutate(countryterritoryCode = africa$ISO_A3)%>%
  mutate_if(is.numeric, as.character) %>% 
  mutate_at('V1', ~replace(., .=="0", NA))%>% 
  mutate_at('countryterritoryCode', ~replace(., .=='-99', 'SOL'))

for (i in 1:nrow(nb.data)) {
  for (j in 1:(ncol(nb.data)-1)) {
    if (!is.na(nb.data[i,j])){
      nb.data[i,j] <- nb.data$countryterritoryCode[as.numeric(nb.data[i,j])]
    }
  }
}

names(nb.data) <- gsub(x = names(nb.data), pattern = "\\V", replacement = "nearctry") 
no_neighbour <- nb.data
no_neighbour[,1:9][!is.na(no_neighbour[,1:9])] <- 1
no_neighbour[,1:9] <- lapply(no_neighbour[,1:9], as.numeric)
no_neighbour$no_neighbour <- rowSums(no_neighbour[,1:9], na.rm=T)
no_neighbour <- no_neighbour[-which(no_neighbour$countryterritoryCode == "DJI"| no_neighbour$countryterritoryCode =="EGY"| #remove non-WHO African countries
                                      no_neighbour$countryterritoryCode =="LBY"| no_neighbour$countryterritoryCode =="MAR"|
                                      no_neighbour$countryterritoryCode =="SOM"|no_neighbour$countryterritoryCode == "SDN" |
                                      no_neighbour$countryterritoryCode =="TUN"|no_neighbour$countryterritoryCode =="SOL"|
                                      no_neighbour$countryterritoryCode =="ESH"),]

#no_neighbour$no_neighbour  <- factor(no_neighbour$no_neighbour,levels=c('0','1','2','3','4','5','6','7','8','9'))

#### 19. latitude####
africa <- geojson_read("./Raw data/Africa1.geojson",what = "sp")
lat <- cbind(countryterritoryCode = africa$ISO_A3,lat = coordinates(africa)[,2])
lat <- data.frame(lat)
lat$countryterritoryCode <- as.character(lat$countryterritoryCode)
lat$lat <- as.numeric(as.character(lat$lat))
lat <- lat[-which(lat$countryterritoryCode == "DJI"| lat$countryterritoryCode =="EGY"|
                    lat$countryterritoryCode =="LBY"| lat$countryterritoryCode =="MAR"|
                    lat$countryterritoryCode =="SOM"|lat$countryterritoryCode == "SDN" |
                    lat$countryterritoryCode =="TUN"|lat$countryterritoryCode =="SOL"|
                    lat$countryterritoryCode =="ESH"),]
lat$lat <- abs(lat$lat)


## 20. under-reporting#####
underreporting <- read_excel('./Raw data/Variables/underreporting/expected deaths.xlsx')
names(underreporting)[5] <- 'ratio_expected_reported'
# underreporting$ratio[underreporting$country=="Botswana"] <- 1.625
# underreporting$ratio[underreporting$country=="Burundi"|underreporting$country=="Eritrea"|underreporting$country=="Seychelles"] <- 3.5
# underreporting$ratio[underreporting$country=="Lesotho"] <- 2.75

#### 21. testing policy index####

test_policy_data<-
  read.csv('./Raw data/Variables/WHO AFRO test/OxCGRT_latest_combined.csv', stringsAsFactors = FALSE)%>%
  dplyr::rename(countryterritoryCode = CountryCode)%>%
  mutate(Date=as.Date(as.character(Date),format="%Y%m%d",origin="1970-01-01")) #

africa_test_policy <- test_policy_data[,c(2,6,29)] %>% filter(countryterritoryCode %in% WHOcountry$countryterritoryCode) # only Protection_elderly have .5

names(africa_test_policy)[3] <- c("Testing_policy")

## there are some having missing, one country Senegal use value from the previous day
africa_test_policy <- arrange(africa_test_policy,countryterritoryCode,Date)
for (i in 1:(nrow(africa_test_policy)-1)){
  if (africa_test_policy$countryterritoryCode[i+1] == africa_test_policy$countryterritoryCode[i] & is.na(africa_test_policy$Testing_policy[i+1]) & !is.na(africa_test_policy$Testing_policy[i]))
    africa_test_policy[i+1,3] <- africa_test_policy[i,3]
}


test_policy_greater2 <-
  filter(africa_test_policy,Testing_policy >= 2,Date <= as.Date('2020-10-31'), Date >= as.Date('2020-02-25')) %>%
  mutate(index=1) %>%
  group_by(countryterritoryCode) %>%
  mutate(test_policy_greater2_day = cumsum(index)) %>%
  filter(row_number()==n()) ##others is 0

test_policy_greater2 <- left_join(WHOcountry,test_policy_greater2)

test_policy_greater2 <- test_policy_greater2 %>%
  mutate(test_policy_greater2_day=replace(test_policy_greater2_day,
                                          is.na(test_policy_greater2_day) &
                                            countryterritoryCode != "COM" &
                                            countryterritoryCode != "GNQ" & 
                                            countryterritoryCode != "GNB" & 
                                            countryterritoryCode != "STP", 0))
## 22. testing policy on November 1st####
test_policy_1101 <- africa_test_policy[africa_test_policy$Date ==as.Date('2020-11-01'),1:3] ##2+3 missing
names(test_policy_1101)[3] <- "Testing_policy_1101"


#### 23. test data quality index####
## test data quality
test_quality<-
  read.csv('./Raw data/Variables/WHO AFRO test/test data quality.csv', stringsAsFactors = FALSE)%>%
  dplyr::rename(countryterritoryCode = Country.Territory.Code)

test_quality$Source.Quality[test_quality$Source.Quality =="No Data"] <- "no data"
test_quality$Source.Quality[test_quality$Source.Quality =="Basic"] <- "basic"
test_quality$Source.Quality[test_quality$Source.Quality =="Satisfactory"] <- "satisfactory"
test_quality$Source.Quality[test_quality$Source.Quality =="Good"] <- "good"

## not useful test_quality$Source.Quality <- factor(test_quality$Source.Quality,levels = c("no data","basic","satisfactory","good"))

##### 24. Tests per capita ########
test_per_cap<-
  read.csv('./Raw data/Variables/WHO AFRO test/lancet test data.csv', stringsAsFactors = FALSE)

test_per_cap$Testing.ratio. <- gsub(" ", "", test_per_cap$Testing.ratio., fixed=TRUE)

names(test_per_cap)[1] <- 'country'
test_per_cap$country <- as.character(test_per_cap$country)
test_per_cap$country <- trimws(test_per_cap$country)

test_per_cap$country[test_per_cap$country=="Cabo Verde"] <- "Cape Verde"
test_per_cap$country[test_per_cap$country=="DR Congo"] <- "Democratic Republic of the Congo"
test_per_cap$country[test_per_cap$country=="Republic of the Congo"] <- "Congo"
#test_per_cap$country[test_per_cap$country=="São Tomé and Príncipe"] <- "Sao Tome and Principe"
test_per_cap$country[test_per_cap$country=="The Gambia"] <- "Gambia"
test_per_cap$country[test_per_cap$country=="Tanzania"] <- "United Republic of Tanzania"
names(test_per_cap)[1] <- 'Country'
##load any data

test_per_cap1 <-left_join(WHOcountry[,c(1,2)],test_per_cap[,c(1,8)])

test_per_cap1$Testing_ratio_100K <- as.numeric(test_per_cap1$Testing.ratio.)/10


##### 25. AUC of stringency#####
policy <- read.table("./Raw data/Variables/Policy/update_Epigroup_Lockdown_Timelines_Dataset_strictnessTimeseries.csv", header = T, sep = ",", quote = '"', stringsAsFactors = F, fill = T)

policy$country[policy$country=="Guinea-Bissau"] <- "Guinea Bissau"
policy$country[policy$country=="Chad " ] <-  "Chad"
#policy$country[policy$country=="Cape Verde"] <-  'Cabo Verde'
policy$country[policy$country=="Côte d'Ivoire"] <-  "Côte d’Ivoire" 
policy$country[policy$country=="Democratic Republic of Congo" ] <-  'Democratic Republic of the Congo' 
policy$country[policy$country=="Eswatini "] <-  "Eswatini"
policy$country[policy$country=="Tanzania"] <-  "United Republic of Tanzania" 
policy$country[policy$country=="Sao Tome and Principe"] <-  "São Tomé and Príncipe" 
names(policy)[1] <- 'Country'

policy <- left_join(policy,WHOcountry)
names(policy)[31:32] <- c('Government_response','Stringency_index')
policy$date <- as.Date(policy$date)
names(policy)

## set the stringency at the latest value for the rest of the time

date1 <- rep(seq(from=as.Date('2020-01-01'), to=as.Date('2020-10-31'),by='day'), length(unique(policy$country)))
Country <- rep(unique(policy$Country),each=305)

data1 <- data.frame(date = date1, Country = Country)
data1 <- data1 %>%
  mutate_if(is.factor, as.character) %>%
  mutate_at("date", as.Date)

data2 <- left_join(data1,policy)

for (i in 1:(nrow(data2)-1)){
  if (data2$Country[i+1] == data2$Country[i] & is.na(data2$Border.closure[i+1]) & !is.na(data2$Border.closure[i]))
    data2[i+1,3:33] <- data2[i,3:33]
}

data2<- data2[complete.cases(data2),]
policy <- data2

str_auc_all <-  filter(policy[,c(1,2,32,33)],date <= as.Date('2020-10-31'), date >= as.Date('2020-02-25')) %>% 
  group_by(Country) %>%
  mutate(date = as.Date(date))%>%
  mutate(x=as.numeric(date)) %>%
  mutate(str_auc_all=auc(x,Stringency_index, type = 'spline'))

str_auc_all <- unique(str_auc_all[,c(2,4,6)])

## 26. strigency index when reach death rate threshold#####
# load data below
WHO_deaths <- WHO_cases_and_deaths[WHO_cases_and_deaths$date <=as.Date('2020-10-31'),c(1,2,10)]

#21 day kernel
WHO_deaths_smooth<- WHO_deaths %>% 
  group_by(country) %>%
  mutate(cum_deaths_per_100k_smoothing=ksmooth(date,cum_deaths_per_100k,kernel="normal",bandwidth=21)$y) #,n.points = length(new_death$date)

names(WHO_deaths_smooth)

## plot cumulative deaths per capita
ggplot(data = WHO_deaths_smooth, aes(x=date, y=cum_deaths_per_100k, group=country)) +
  geom_bar(stat="identity", position=position_dodge(),colour = 'grey') +
  facet_wrap(~country,scales= 'free',ncol=6)+
  geom_smooth(data = WHO_deaths_smooth,aes(x=date, y=cum_deaths_per_100k_smoothing, group=country), stat="identity")+ #,color = index
  #scale_colour_manual(values=c("blue","red"),name = '',labels=c("7-Day Rolling Average for cases","7-Day Rolling Average for deaths")) +
  theme_bw() +
  #theme(legend.position = "bottom",legend.text = element_text(size = 20))+ #, face = "bold"c(0.82, 0.9)
  xlab("Date") + ylab("Cumulative deaths per 100k") +
  theme(axis.title= element_text(size=12, face= "bold", vjust=0.5, hjust=0.5)) +
  theme(axis.text = element_text(color = "black", size=10)) +
  theme(strip.text = element_text(size = 13, face = "bold"))+ #bold.italic
  theme(plot.margin=unit(c(0.5,0.8,0.5,0.5),"cm")) # 22 16

# statistics by splitting the period to four periods and see what levels of cumulative mortalities reach by the end of each period
# A threshold of 0.1 was selected because most countries reached this threshold from March to July when deaths in the WHO African region increased exponentially (Figure 1B).
## But several other thresholds from 0.001 to 0.2 were also explored for validation
block <- WHO_deaths_smooth[which(WHO_deaths_smooth$date==as.Date('2020-04-27')|
                                   WHO_deaths_smooth$date==as.Date('2020-06-29')|
                                   WHO_deaths_smooth$date==as.Date('2020-08-31')|
                                   WHO_deaths_smooth$date==as.Date('2020-10-31')),]

library(tableone)
var <- c("cum_deaths_per_100k","cum_deaths_per_100k_smoothing")
taball <- CreateTableOne(vars = var,strata = "date", data = block)
a <- print(taball,nonnormal = c("cum_deaths_per_100k","cum_deaths_per_100k_smoothing"))

## by cumulative deaths per 100K, get the dates when the cumulative mortalitity reach the following threshold 0.001 to 0.2
by_cum_death_per100K0 <- WHO_deaths_smooth[WHO_deaths_smooth$cum_deaths_per_100k_smoothing>=0.05,]
unique(by_cum_death_per100K0$country)
subset(unique(WHO_deaths_smooth$country), !(unique(WHO_deaths_smooth$country) %in% unique(by_cum_death_per100K0$country))) #"Burundi", "Eritrea" , "Seychelles" , "United Republic of Tanzania"
by_cum_death_per100K0 <- by_cum_death_per100K0 %>%
  group_by(country) %>% 
  arrange(country,date) %>%
  filter(row_number()==1)
names(by_cum_death_per100K0)[1] <- 'cum_death_per100K_0.05' 

by_cum_death_per100K1 <- WHO_deaths_smooth[WHO_deaths_smooth$cum_deaths_per_100k_smoothing>=0.2,]
unique(by_cum_death_per100K1$country)
subset(unique(WHO_deaths_smooth$country), !(unique(WHO_deaths_smooth$country) %in% unique(by_cum_death_per100K1$country))) #"Burundi", "Eritrea" , "Seychelles" , "United Republic of Tanzania"
by_cum_death_per100K1 <- by_cum_death_per100K1 %>%
  group_by(country) %>% 
  arrange(country,date) %>%
  filter(row_number()==1)
names(by_cum_death_per100K1)[1] <- 'cum_death_per100K_0.2'

by_cum_death_per100K2 <- WHO_deaths_smooth[WHO_deaths_smooth$cum_deaths_per_100k_smoothing>=0.15,]
unique(by_cum_death_per100K2$country)
subset(unique(WHO_deaths_smooth$country), !(unique(WHO_deaths_smooth$country) %in% unique(by_cum_death_per100K2$country))) #"Burundi", "Eritrea" , "Seychelles" 
by_cum_death_per100K2 <- by_cum_death_per100K2 %>%
  group_by(country) %>% 
  arrange(country,date) %>%
  filter(row_number()==1)
names(by_cum_death_per100K2)[1] <- 'cum_death_per100K_0.15'

by_cum_death_per100K3 <- WHO_deaths_smooth[WHO_deaths_smooth$cum_deaths_per_100k_smoothing>=0.1,]
unique(by_cum_death_per100K3$country)
subset(unique(WHO_deaths_smooth$country), !(unique(WHO_deaths_smooth$country) %in% unique(by_cum_death_per100K3$country))) #"Burundi", "Eritrea" , "Seychelles" 
by_cum_death_per100K3 <- by_cum_death_per100K3 %>%
  group_by(country) %>% 
  arrange(country,date) %>%
  filter(row_number()==1)
names(by_cum_death_per100K3)[1] <- 'cum_death_per100K_0.1'

by_cum_death_per100K4 <- WHO_deaths_smooth[WHO_deaths_smooth$cum_deaths_per_100k_smoothing>=0.03,]
unique(by_cum_death_per100K4$country)
subset(unique(WHO_deaths_smooth$country), !(unique(WHO_deaths_smooth$country) %in% unique(by_cum_death_per100K4$country))) # "Burundi"    "Eritrea"    "Seychelles" 
by_cum_death_per100K4 <- by_cum_death_per100K4 %>%
  group_by(country) %>% 
  arrange(country,date) %>%
  filter(row_number()==1)
names(by_cum_death_per100K4)[1] <- 'cum_death_per100K_0.03'

by_cum_death_per100K5 <- WHO_deaths_smooth[WHO_deaths_smooth$cum_deaths_per_100k_smoothing>=0.01,]
unique(by_cum_death_per100K5$country)
subset(unique(WHO_deaths_smooth$country), !(unique(WHO_deaths_smooth$country) %in% unique(by_cum_death_per100K5$country))) # "Burundi"    "Eritrea"    "Seychelles" 
by_cum_death_per100K5 <- by_cum_death_per100K5 %>%
  group_by(country) %>% 
  arrange(country,date) %>%
  filter(row_number()==1)
names(by_cum_death_per100K5)[1] <- 'cum_death_per100K_0.01'

by_cum_death_per100K6 <- WHO_deaths_smooth[WHO_deaths_smooth$cum_deaths_per_100k_smoothing>=0.008,]
unique(by_cum_death_per100K6$country)
subset(unique(WHO_deaths_smooth$country), !(unique(WHO_deaths_smooth$country) %in% unique(by_cum_death_per100K6$country))) #  "Eritrea"    "Seychelles" 
by_cum_death_per100K6 <- by_cum_death_per100K6 %>%
  group_by(country) %>% 
  arrange(country,date) %>%
  filter(row_number()==1)
names(by_cum_death_per100K6)[1] <- 'cum_death_per100K_0.008'

by_cum_death_per100K7 <- WHO_deaths_smooth[WHO_deaths_smooth$cum_deaths_per_100k_smoothing>=0.004,]
unique(by_cum_death_per100K7$country)
subset(unique(WHO_deaths_smooth$country), !(unique(WHO_deaths_smooth$country) %in% unique(by_cum_death_per100K7$country))) #  "Eritrea"    "Seychelles" 
by_cum_death_per100K7 <- by_cum_death_per100K7 %>%
  group_by(country) %>% 
  arrange(country,date) %>%
  filter(row_number()==1)
names(by_cum_death_per100K7)[1] <- 'cum_death_per100K_0.004'

by_cum_death_per100K8 <- WHO_deaths_smooth[WHO_deaths_smooth$cum_deaths_per_100k_smoothing>=0.002,]
unique(by_cum_death_per100K8$country)
subset(unique(WHO_deaths_smooth$country), !(unique(WHO_deaths_smooth$country) %in% unique(by_cum_death_per100K8$country))) # "  "Eritrea"    "Seychelles" 
by_cum_death_per100K8 <- by_cum_death_per100K8 %>%
  group_by(country) %>% 
  arrange(country,date) %>%
  filter(row_number()==1)
names(by_cum_death_per100K8)[1] <- 'cum_death_per100K_0.002'

by_cum_death_per100K9 <- WHO_deaths_smooth[WHO_deaths_smooth$cum_deaths_per_100k_smoothing>=0.001,]
unique(by_cum_death_per100K9$country)
subset(unique(WHO_deaths_smooth$country), !(unique(WHO_deaths_smooth$country) %in% unique(by_cum_death_per100K9$country))) #  "Eritrea"    "Seychelles" 
by_cum_death_per100K9 <- by_cum_death_per100K9 %>%
  group_by(country) %>% 
  arrange(country,date) %>%
  filter(row_number()==1)
names(by_cum_death_per100K9)[1] <- 'cum_death_per100K_0.001'

by_cum_death_per100K <- 
  by_cum_death_per100K9[,c(2,1)] %>% 
  left_join(by_cum_death_per100K8[,1:2])%>% 
  left_join(by_cum_death_per100K7[,1:2])%>% 
  left_join(by_cum_death_per100K6[,1:2])%>% 
  left_join(by_cum_death_per100K5[,1:2])%>% 
  left_join(by_cum_death_per100K4[,1:2])%>% 
  left_join(by_cum_death_per100K0[,1:2])%>% 
  left_join(by_cum_death_per100K3[,1:2])%>% 
  left_join(by_cum_death_per100K2[,1:2])%>% 
  left_join(by_cum_death_per100K1[,1:2])



death_threshold <-  by_cum_death_per100K
death_threshold0 <- left_join(death_threshold, unique(WHO_cases_and_deaths[,c(2,8)]))


## combine with the policy data above 

str <- policy[,c(1,2,33,32)]

str0 <- str
names(death_threshold0)
names(str0)[c(1,4)] <- c('cum_death_per100K_0.001','str_cum_death_per100K_0.001')
death_threshold0 <- left_join(death_threshold0,str0[,-2])
death_threshold0$str_cum_death_per100K_0.001[which(is.na(death_threshold0$str_cum_death_per100K_0.001) & !is.na(death_threshold0$cum_death_per100K_0.001))] <- 0


names(death_threshold0)
names(str0)[c(1,4)] <- c('cum_death_per100K_0.002','str_cum_death_per100K_0.002')
death_threshold0 <- left_join(death_threshold0,str0[,-2])
death_threshold0$str_cum_death_per100K_0.002[which(is.na(death_threshold0$str_cum_death_per100K_0.002) & !is.na(death_threshold0$cum_death_per100K_0.002))] <- 0

names(death_threshold0)
names(str0)[c(1,4)] <- c('cum_death_per100K_0.004','str_cum_death_per100K_0.004')
death_threshold0 <- left_join(death_threshold0,str0[,-2])
death_threshold0$str_cum_death_per100K_0.004[which(is.na(death_threshold0$str_cum_death_per100K_0.004) & !is.na(death_threshold0$cum_death_per100K_0.004))] <- 0

names(death_threshold0)
names(str0)[c(1,4)] <- c('cum_death_per100K_0.008','str_cum_death_per100K_0.008')
death_threshold0 <- left_join(death_threshold0,str0[,-2])
death_threshold0$str_cum_death_per100K_0.008[which(is.na(death_threshold0$str_cum_death_per100K_0.008) & !is.na(death_threshold0$cum_death_per100K_0.008))] <- 0


names(death_threshold0)
names(str0)[c(1,4)] <- c('cum_death_per100K_0.01','str_cum_death_per100K_0.01')
death_threshold0 <- left_join(death_threshold0,str0[,-2])
death_threshold0$str_cum_death_per100K_0.01[which(is.na(death_threshold0$str_cum_death_per100K_0.01) & !is.na(death_threshold0$cum_death_per100K_0.01))] <- 0


names(death_threshold0)
names(str0)[c(1,4)] <- c('cum_death_per100K_0.03','str_cum_death_per100K_0.03')
death_threshold0 <- left_join(death_threshold0,str0[,-2])
death_threshold0$str_cum_death_per100K_0.03[which(is.na(death_threshold0$str_cum_death_per100K_0.03) & !is.na(death_threshold0$cum_death_per100K_0.03))] <- 0

names(death_threshold0)
names(str0)[c(1,4)] <- c('cum_death_per100K_0.05','str_cum_death_per100K_0.05')
death_threshold0 <- left_join(death_threshold0,str0[,-2])
death_threshold0$str_cum_death_per100K_0.05[which(is.na(death_threshold0$str_cum_death_per100K_0.05) & !is.na(death_threshold0$cum_death_per100K_0.05))] <- 0

names(death_threshold0)
names(str0)[c(1,4)] <- c('cum_death_per100K_0.1','str_cum_death_per100K_0.1')
death_threshold0 <- left_join(death_threshold0,str0[,-2])
death_threshold0$str_cum_death_per100K_0.1[which(is.na(death_threshold0$str_cum_death_per100K_0.1) & !is.na(death_threshold0$cum_death_per100K_0.1))] <- 0


names(death_threshold0)
names(str0)[c(1,4)] <- c('cum_death_per100K_0.15','str_cum_death_per100K_0.15')
death_threshold0 <- left_join(death_threshold0,str0[,-2])
death_threshold0$str_cum_death_per100K_0.15[which(is.na(death_threshold0$str_cum_death_per100K_0.15) & !is.na(death_threshold0$cum_death_per100K_0.15))] <- 0


names(death_threshold0)
names(str0)[c(1,4)] <- c('cum_death_per100K_0.2','str_cum_death_per100K_0.2')
death_threshold0 <- left_join(death_threshold0,str0[,-2])
death_threshold0$str_cum_death_per100K_0.2[which(is.na(death_threshold0$str_cum_death_per100K_0.2) & !is.na(death_threshold0$cum_death_per100K_0.2))] <- 0


str_threshold <- death_threshold0[,c(12,9,20)]
str_threshold <- left_join(WHOcountry,str_threshold)

# median(str_threshold$cum_death_per100K_0.1, na.rm=T) ## using the median data "2020-05-17"
# missing <- str[which(str$date==as.Date("2020-05-17")&(str$Country =='Burundi'|str$Country =='Eritrea')),]
# str_threshold$str_cum_death_per100K_0.1[str_threshold$Country=='Burundi'] <- missing$Stringency_index[missing$Country=='Burundi']
# str_threshold$str_cum_death_per100K_0.1[str_threshold$Country=='Eritrea'] <- missing$Stringency_index[missing$Country=='Eritrea']


predictor <-
  pop2[,-3] %>%
  left_join(pop_den2[,-c(1,3)])%>%
  left_join(urban_pop2[,-c(1,3)])%>%
  left_join(Pop_65_age2[,-c(1,3)])%>%
  left_join(SEX2[,-c(1,3)])%>%
  left_join(gdp_per_capita2[,-c(1,3)])%>%
  left_join(hdi2[,-c(1,3)])%>%
  left_join(airport_africa_no1)%>%
  left_join(airport_africa_seats1)%>%
  left_join(Current_expenditures_health2[,-c(1,3)])%>%
  left_join(vulnerable[,-c(1,3)])%>%
  left_join(Burden_communicable2[,-c(1,3)])%>%
  left_join(Burden_non_communicable2[,-c(1,3)])%>%
  left_join(Hiv2[,-c(1,3)])%>%
  left_join(Diabetes2[,-c(1,3)])%>%
  left_join(readiness[,c(2,6,3)])%>%
  left_join(no_neighbour[,10:11])%>%
  left_join(lat)%>%
  left_join(underreporting[,c(2,5)])%>%
  left_join(test_policy_greater2[,c(2,6)])%>%
  left_join(test_policy_1101[,-2])%>%
  left_join(test_quality[,c(2,8)])%>%
  left_join(test_per_cap1[,c(2,4)])%>%
  left_join(str_auc_all[,-1])%>%
  left_join(str_threshold[,-c(1,3)])


predictor$lat[is.na(predictor$lat)] <- 0.1864 #fill lat of STP
predictor$no_neighbour[is.na(predictor$no_neighbour)] <- 0 # fill neighbour of STP

save(predictor,
     file="./R data/predictors.RData")

## combine with the outcome list#####
data_combine <- 
  predictor%>%
  left_join(outcome_list)

save(data_combine,WHO_cases_and_deaths,death_threshold0,
     file="./R data/combined data pre-analysis.RData")
