### multibinomial
library(ggplot2)
library(ggrepel)
library(tidyverse)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##load data_for_analysing_mortality_1stWAVE updated.RData#######
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
load("./R data/data_for_analysing_mortality_1stWAVE updated.RData")

## generate cat predictor for testing policy
library(gtools)
a1 <- data_analysis_fixed[,c(2,31)] %>% 
  mutate_if(is.numeric, ~quantcut(., q=2, na.rm=TRUE))
a2 <- a1 %>%
  summarise_at(c(2), ~levels(.)[1])# get the reference levels of each factor column, used later
a1 <- a1[,c(1:2)] %>%
  mutate_if(is.factor, as.character)
a1 <- a1 %>%
  mutate_at(c("test_policy_greater2_day"),
            ~replace(., is.na(.),"Missing"))
a1 <- a1 %>%
  mutate_at(c(2), as.factor)

for (i in names(a2)) {
  a1 <- a1 %>%
    mutate_at(i, ~relevel(.,a2[,i][1]))#use the lowere 25% as the reference (from a2)
}

names(a1)[2] <- paste0(names(a1)[2],".cat")
data_analysis_fixed1 <- left_join(data_analysis_fixed,a1)

## re-set Source.Quality to two-level factor
data_analysis_fixed1$Source.Quality[data_analysis_fixed1$Source.Quality =="no data"|data_analysis_fixed1$Source.Quality =="basic"] <- 'No to basic'
data_analysis_fixed1$Source.Quality[data_analysis_fixed1$Source.Quality =="good"|data_analysis_fixed1$Source.Quality =="satisfactory"] <- 'Satisfactory to good'
data_analysis_fixed1$Source.Quality <- factor(data_analysis_fixed1$Source.Quality,levels = c("No to basic","Satisfactory to good"))

## re-set missing testing policy to below median
data_analysis_fixed1$test_policy_greater2_day.cat <- as.character(data_analysis_fixed1$test_policy_greater2_day.cat)
data_analysis_fixed1$test_policy_greater2_day.cat[data_analysis_fixed1$test_policy_greater2_day.cat =="Missing"|data_analysis_fixed1$test_policy_greater2_day.cat =="[0,28]"] <- 'Below median'
data_analysis_fixed1$test_policy_greater2_day.cat[data_analysis_fixed1$test_policy_greater2_day.cat =="(28,250]"] <- 'Above median'
data_analysis_fixed1$test_policy_greater2_day.cat <- factor(data_analysis_fixed1$test_policy_greater2_day.cat,levels = c("Below median","Above median"))


## remove outliers or countries with missing predictors
data_analysis_fixed2 <- data_analysis_fixed1[-which(data_analysis_fixed1$countryterritoryCode=="ERI"|
                                                      data_analysis_fixed1$countryterritoryCode=="BDI"|
                                                      data_analysis_fixed1$countryterritoryCode=="TZA"|
                                                      data_analysis_fixed1$Hiv==999),]

## need the raw str_auc_all to generate the new outcome, so load combined data pre-analysis updated.RData and combine
names(data_analysis_fixed2)[35] <- "str_auc_all_scale"
data_analysis_fixed2 <- left_join(data_analysis_fixed2,data_combine[,c(2,27)])

data_analysis_fixed2 <- within(data_analysis_fixed2,{
  outcome_cat <- NA
  outcome_cat[str_auc_all >= median(str_auc_all) & cum_deaths_per_100k_1st >= median(cum_deaths_per_100k_1st)] <- 'high_high'
  outcome_cat[str_auc_all >= median(str_auc_all)& cum_deaths_per_100k_1st < median(cum_deaths_per_100k_1st)] <- 'high_low'
  outcome_cat[str_auc_all < median(str_auc_all)& cum_deaths_per_100k_1st >= median(cum_deaths_per_100k_1st)] <- 'low_high'
  outcome_cat[str_auc_all < median(str_auc_all)& cum_deaths_per_100k_1st < median(cum_deaths_per_100k_1st)] <- 'low_low'
})


table(data_analysis_fixed2$outcome_cat)

# data_analysis_fixed2$Country[data_analysis_fixed2$outcome_cat=='high_high']
# data_analysis_fixed2$Country[data_analysis_fixed2$outcome_cat=='high_low']
# data_analysis_fixed2$Country[data_analysis_fixed2$outcome_cat=='low_high']
# data_analysis_fixed2$Country[data_analysis_fixed2$outcome_cat=='low_low']



require(foreign)
require(nnet)
require(ggplot2)
require(reshape2)
library(AICcmodavg)
data_analysis_fixed2$outcome_cat <- factor(data_analysis_fixed2$outcome_cat, levels = c('high_high','high_low','low_high','low_low'))
data_analysis_fixed2$outcome_cat<- relevel(data_analysis_fixed2$outcome_cat, ref = 'low_low')

## Best multivariable model####
po <- multinom(outcome_cat ~   urban_pop + vulnerable_index , data = data_analysis_fixed2)

## correlation r > 0.6
#  HDI and vulnerable, HDI and communicable, HDI and GDP per capita, 
#  population and airport seats, Communicable and non-communicable

summary(po) ##109.1323
AIC(po)
AICc(po) #114.7573

multi_AIC <- data.frame(cbind(exp(cbind(OR = t(coef(po)), as.data.frame(confint(po,level=0.95))))))
multi_AIC$var <- rownames(multi_AIC)
multi_AIC <- multi_AIC[!grepl("(Intercept)", multi_AIC$var),]
multi_AIC[,1:9] <- round(multi_AIC[,1:9],digits = 4)
multi_AIC$OR_H_L <- paste0(as.character(multi_AIC$OR.high_low), ' (',as.character(multi_AIC$X2.5...high_low) ,'-',as.character(multi_AIC$X97.5...high_low),')')
multi_AIC$OR_L_H <- paste0(as.character(multi_AIC$OR.low_high), ' (',as.character(multi_AIC$X2.5...low_high) ,'-',as.character(multi_AIC$X97.5...low_high),')')
multi_AIC$OR_H_H <- paste0(as.character(multi_AIC$OR.high_high), ' (',as.character(multi_AIC$X2.5...high_high) ,'-',as.character(multi_AIC$X97.5...high_high),')')



## add test_policy_greater2_day.cat
po3 <- multinom(outcome_cat ~  urban_pop + vulnerable_index + test_policy_greater2_day.cat, data = data_analysis_fixed2)

summary(po3) 
AIC(po3)
AICc(po3) #119.1739

multi_AIC3 <- data.frame(cbind(exp(cbind(OR = t(coef(po3)), as.data.frame(confint(po3,level=0.95))))))
multi_AIC3$var <- rownames(multi_AIC3)
multi_AIC3 <- multi_AIC3[!grepl("(Intercept)", multi_AIC3$var),]

multi_AIC3[,1:9] <- round(multi_AIC3[,1:9],digits = 4)
multi_AIC3$OR_H_L <- paste0(as.character(multi_AIC3$OR.high_low), ' (',as.character(multi_AIC3$X2.5...high_low) ,'-',as.character(multi_AIC3$X97.5...high_low),')')
multi_AIC3$OR_L_H <- paste0(as.character(multi_AIC3$OR.low_high), ' (',as.character(multi_AIC3$X2.5...low_high) ,'-',as.character(multi_AIC3$X97.5...low_high),')')
multi_AIC3$OR_H_H <- paste0(as.character(multi_AIC3$OR.high_high), ' (',as.character(multi_AIC3$X2.5...high_high) ,'-',as.character(multi_AIC3$X97.5...high_high),')')


## add Source.Quality
po4 <- multinom(outcome_cat ~  urban_pop + vulnerable_index + Source.Quality, data = data_analysis_fixed2)

summary(po4) #
AIC(po4)
AICc(po4) #124.6328

multi_AIC4 <- data.frame(cbind(exp(cbind(OR = t(coef(po4)), as.data.frame(confint(po4,level=0.95))))))
multi_AIC4$var <- rownames(multi_AIC4)
multi_AIC4 <- multi_AIC4[!grepl("(Intercept)", multi_AIC4$var),]

multi_AIC4[,1:9] <- round(multi_AIC4[,1:9],digits = 4)
multi_AIC4$OR_H_L <- paste0(as.character(multi_AIC4$OR.high_low), ' (',as.character(multi_AIC4$X2.5...high_low) ,'-',as.character(multi_AIC4$X97.5...high_low),')')
multi_AIC4$OR_L_H <- paste0(as.character(multi_AIC4$OR.low_high), ' (',as.character(multi_AIC4$X2.5...low_high) ,'-',as.character(multi_AIC4$X97.5...low_high),')')
multi_AIC4$OR_H_H <- paste0(as.character(multi_AIC4$OR.high_high), ' (',as.character(multi_AIC4$X2.5...high_high) ,'-',as.character(multi_AIC4$X97.5...high_high),')')


## add Testing_per_100K_scale
po5 <- multinom(outcome_cat ~  urban_pop + vulnerable_index + Testing_ratio_100K, data = data_analysis_fixed2) ####case_rate now Testing_per_100K_scale

summary(po5) # AIC 106.3181 add pop den 105.1271
AIC(po5)
AICc(po5) #122.2256

multi_AIC5 <- data.frame(cbind(exp(cbind(OR = t(coef(po5)), as.data.frame(confint(po5,level=0.95))))))
multi_AIC5$var <- rownames(multi_AIC5)
multi_AIC5 <- multi_AIC5[!grepl("(Intercept)", multi_AIC5$var),]

multi_AIC5[,1:9] <- round(multi_AIC5[,1:9],digits = 4)
multi_AIC5$OR_H_L <- paste0(as.character(multi_AIC5$OR.high_low), ' (',as.character(multi_AIC5$X2.5...high_low) ,'-',as.character(multi_AIC5$X97.5...high_low),')')
multi_AIC5$OR_L_H <- paste0(as.character(multi_AIC5$OR.low_high), ' (',as.character(multi_AIC5$X2.5...low_high) ,'-',as.character(multi_AIC5$X97.5...low_high),')')
multi_AIC5$OR_H_H <- paste0(as.character(multi_AIC5$OR.high_high), ' (',as.character(multi_AIC5$X2.5...high_high) ,'-',as.character(multi_AIC5$X97.5...high_high),')')



## Supplementary table 4 save as table####
library(WriteXLS)
WriteXLS(x=c('multi_AIC3','multi_AIC4','multi_AIC5'), ExcelFileName = './Results/Tables//Supplementary table 4 P2 logistic_add_test.xlsx',  
         verbose = FALSE, row.names = T, col.names = TRUE,
         na = "",envir = parent.frame())

