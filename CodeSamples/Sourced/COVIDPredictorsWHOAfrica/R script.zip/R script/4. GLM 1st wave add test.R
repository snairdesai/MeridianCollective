library(splines)
library(Epi)
library(glmnet)
library(WriteXLS)
library(tidyverse)
library(reshape2)
library(mgcv)
library(MASS)
require(MESS)
library(dplyr)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##load data_for_analysing_mortality_1stWAVE updated.RData#######
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
load("./R data/data_for_analysing_mortality_1stWAVE updated.RData")

## generate cat predictor for testing policy
library(gtools)
a1 <- data_analysis_fixed[,c(2,31)] %>% 
  mutate_if(is.numeric, ~quantcut(., q=2, na.rm=TRUE))
a2 <- a1 %>%
  summarise_at(c(2), ~levels(.)[1])# get the reference levels of each factor column, used later
a1 <- a1[,c(1:2)] %>%
  mutate_if(is.factor, as.character)
a1 <- a1 %>%
  mutate_at(c("test_policy_greater2_day"),
            ~replace(., is.na(.),"Missing"))
a1 <- a1 %>%
  mutate_at(c(2), as.factor)

for (i in names(a2)) {
  a1 <- a1 %>%
    mutate_at(i, ~relevel(.,a2[,i][1]))#use the lowere 25% as the reference (from a2)
}

names(a1)[2] <- paste0(names(a1)[2],".cat")
data_analysis_fixed1 <- left_join(data_analysis_fixed,a1)

## re-set Source.Quality to two-level factor
data_analysis_fixed1$Source.Quality[data_analysis_fixed1$Source.Quality =="no data"|data_analysis_fixed1$Source.Quality =="basic"] <- 'No to basic'
data_analysis_fixed1$Source.Quality[data_analysis_fixed1$Source.Quality =="good"|data_analysis_fixed1$Source.Quality =="satisfactory"] <- 'Satisfactory to good'
data_analysis_fixed1$Source.Quality <- factor(data_analysis_fixed1$Source.Quality,levels = c("No to basic","Satisfactory to good"))

## re-set missing testing policy to below median
data_analysis_fixed1$test_policy_greater2_day.cat <- as.character(data_analysis_fixed1$test_policy_greater2_day.cat)
data_analysis_fixed1$test_policy_greater2_day.cat[data_analysis_fixed1$test_policy_greater2_day.cat =="Missing"|data_analysis_fixed1$test_policy_greater2_day.cat =="[0,28]"] <- 'Below median'
data_analysis_fixed1$test_policy_greater2_day.cat[data_analysis_fixed1$test_policy_greater2_day.cat =="(28,250]"] <- 'Above median'
data_analysis_fixed1$test_policy_greater2_day.cat <- factor(data_analysis_fixed1$test_policy_greater2_day.cat,levels = c("Below median","Above median"))


## remove outliers or countries with missing predictors
data_analysis_fixed2 <- data_analysis_fixed1[-which(data_analysis_fixed1$countryterritoryCode=="ERI"|
                                                     data_analysis_fixed1$countryterritoryCode=="BDI"|
                                                     data_analysis_fixed1$countryterritoryCode=="TZA"|
                                                     data_analysis_fixed1$Hiv==999),]


# Re-load Best model ####
po1 <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) + 
               urban_pop + airport_seats + Hiv, data_analysis_fixed2,family = poisson) 

summary(po1)
AIC(po1) ##  623.2754
AICc(po1) ##624.9421

multi_AIC <- data.frame(coef(summary(po1)))
multi_AIC$var <- rownames(multi_AIC)
multi_AIC <- multi_AIC[,-3]
names(multi_AIC) <- c("Coefficient","SD","p","var") 

multi_AIC <- multi_AIC[!grepl("(Intercept)", multi_AIC$var),]

multi_AIC$RR <- exp(multi_AIC$Coefficient)
multi_AIC$Lower <- exp(multi_AIC$Coefficient -1.96*multi_AIC$SD)
multi_AIC$Upper <- exp(multi_AIC$Coefficient +1.96*multi_AIC$SD)
multi_AIC[,c(3,5,6,7)] <- round(multi_AIC[,c(3,5,6,7)],digits = 3)
multi_AIC$RR2 <- paste0(as.character(multi_AIC$RR), ' (',as.character(multi_AIC$Lower) ,'-',as.character(multi_AIC$Upper),')')


## Extended Data Fig. 3 Correlations matrix before adding the test variables######

dat_cor <- data_analysis_fixed2[,c(11,17,22,40,33,34)] 

names(dat_cor) <- c("Urban population\n(% of total population)" ,
                    "Volume of international\nair travel",
                    'Prevalence of HIV, total\n(% of population ages 15-49)',
                    "Days with testing policy index >= 2","Test data quality",
                    "Total number of tests per 100K\npopulation as of 31 Dec. 2020")

dat_cor <- dat_cor %>%   
  mutate_at(c(1:6),funs(as.numeric))

res <- cor(dat_cor, method = "spearman",use = "complete.obs")

library(corrplot)
library(Cairo)
cairo_pdf('./Results/Extended Data/Extended Data Fig. 3.pdf',width=12,height=9) #,family="Arial Unicode MS"
col <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD", "#4477AA"))
par(mar=c(0,0,0,0))
corrplot(res, method="color", col=col(200),  
         type="lower", order="original", 
         addCoef.col = "black", # Add coefficient of correlation
         tl.col="black", tl.srt=45, tl.offset=0.8,number.digits=3,#Text label color and rotation
         # hide correlation coefficient on the principal diagonal
         diag=FALSE,
         mar = c(0, 0, 0, 0))
dev.off()


## add test_policy_greater2_day.cat#####
po2 <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) +
               urban_pop + airport_seats + Hiv  + test_policy_greater2_day.cat, data_analysis_fixed2,family = poisson)

summary(po2)
AIC(po2) ##625.0483
AICc(po2) ##627.4483

multi_AIC2 <- data.frame(coef(summary(po2)))
multi_AIC2$var <- rownames(multi_AIC2)
multi_AIC2 <- multi_AIC2[,-3]
names(multi_AIC2) <- c("Coefficient","SD","p","var")

multi_AIC2 <- multi_AIC2[!grepl("(Intercept)", multi_AIC2$var),]

multi_AIC2$RR <- exp(multi_AIC2$Coefficient)
multi_AIC2$Lower <- exp(multi_AIC2$Coefficient -1.96*multi_AIC2$SD)
multi_AIC2$Upper <- exp(multi_AIC2$Coefficient +1.96*multi_AIC2$SD)

multi_AIC2[,c(3,5,6,7)] <- round(multi_AIC2[,c(3,5,6,7)],digits = 3)
multi_AIC2$RR3 <- paste0(as.character(multi_AIC2$RR), ' (',as.character(multi_AIC2$Lower) ,'-',as.character(multi_AIC2$Upper),')')

### add test data quality####
po3 <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) +
               urban_pop + airport_seats + Hiv  + Source.Quality, data_analysis_fixed2,family = poisson)

summary(po3)
AIC(po3) ## 625.064
AICc(po3) ##627.464

multi_AIC3 <- data.frame(coef(summary(po3)))
multi_AIC3$var <- rownames(multi_AIC3)
multi_AIC3 <- multi_AIC3[,-3]
names(multi_AIC3) <- c("Coefficient","SD","p","var")

multi_AIC3 <- multi_AIC3[!grepl("(Intercept)", multi_AIC3$var),]

multi_AIC3$RR <- exp(multi_AIC3$Coefficient)
multi_AIC3$Lower <- exp(multi_AIC3$Coefficient -1.96*multi_AIC3$SD)
multi_AIC3$Upper <- exp(multi_AIC3$Coefficient +1.96*multi_AIC3$SD)

multi_AIC3[,c(3,5,6,7)] <- round(multi_AIC3[,c(3,5,6,7)],digits = 3)
multi_AIC3$RR4 <- paste0(as.character(multi_AIC3$RR), ' (',as.character(multi_AIC3$Lower) ,'-',as.character(multi_AIC3$Upper),')')


### add test per capita#####
po4 <- glmer(cum_deaths_predicted_1st ~ offset(pop_log) + (1|Country) +
               urban_pop + airport_seats + Hiv  + Testing_ratio_100K, data_analysis_fixed2,family = poisson)

summary(po4)
AIC(po4) ##624.0968
AICc(po4) ##626.4968

multi_AIC4 <- data.frame(coef(summary(po4)))
multi_AIC4$var <- rownames(multi_AIC4)
multi_AIC4 <- multi_AIC4[,-3]
names(multi_AIC4) <- c("Coefficient","SD","p","var")

multi_AIC4 <- multi_AIC4[!grepl("(Intercept)", multi_AIC4$var),]

multi_AIC4$RR <- exp(multi_AIC4$Coefficient)
multi_AIC4$Lower <- exp(multi_AIC4$Coefficient -1.96*multi_AIC4$SD)
multi_AIC4$Upper <- exp(multi_AIC4$Coefficient +1.96*multi_AIC4$SD)

multi_AIC4[,c(3,5,6,7)] <- round(multi_AIC4[,c(3,5,6,7)],digits = 3)
multi_AIC4$RR6 <- paste0(as.character(multi_AIC4$RR), ' (',as.character(multi_AIC4$Lower) ,'-',as.character(multi_AIC4$Upper),')')

## Supplementary table 3####
WriteXLS(x=c('multi_AIC2','multi_AIC3','multi_AIC4'), ExcelFileName = './Results/Tables/Supplementary table 3 P2 multi_add_test.xlsx',  
         verbose = FALSE, row.names = T, col.names = TRUE,
         na = "",envir = parent.frame())

## Extended Data Fig. 4 plotting########

gr <- c("Urban population (% of total population)", ##'Refugee population by \ncountry or territory of origin',
        "Volume of international air travel",
        'Prevalence of HIV, total (% of population\nages 15-49)',
        "Days with testing policy index >= 2, above median","Test data quality, satisfactory to good",
        "Total number of tests per 100K population\nas of 31 Dec. 2020")

lab <- data.frame(v1=rep(c(0.55,0.45,0.35,0.25,0.15,0.05),1),
                  v2=rep(c(1),each=6),
                  v3=c(gr))


data_table <- ggplot(lab, aes(x = v2, y = v1, label = format(v3, nsmall = 1))) +
  geom_text(size = 4, hjust=0, vjust=0.5,lineheight = .8) + 
  annotate("text", label = "Variable", x = 1, y = 0.65, hjust=0,vjust=0, fontface = "bold") +
  # annotate("text", label = "Subgroup", x = 1.75, y = 88, hjust=0,vjust=0.5, fontface = "bold") +
  xlim(1,2.5) +
  #ylim(0,0.6)+
  scale_y_continuous(expand = c(0.05,0.05))+
  theme_bw() +
  #geom_hline(yintercept=c(20.5,21.5)) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        axis.text.x = element_blank(),#element_text(colour="white"),
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),#element_line(colour="white"),
        plot.margin = unit(c(0.5,0,3,0.2), "lines")) +
  labs(x="",y="") +
  coord_cartesian(xlim=c(1,2.5))
data_table


###### add test data policy#####
multi_AIC2 <- within(multi_AIC2,{
  index <- NA
  index[p >= 0.05] <- 'black'
  index[Lower >= 1 & p < 0.05] <- 'red'
  index[Upper <= 1 & p < 0.05] <- 'blue'
})

multi_AIC2$RR
multi_AIC2$Lower
multi_AIC2$Upper
multi_AIC2$index
multi_AIC2$var

#options(OutDec = ".")
dat<- data.frame(group = c(0.55,0.45,0.35,0.25,0.15,0.05),
                 cen = c(1.593,1.308,1.411,1.128,"",""),
                 low = c(1.238,1.035,1.110,0.689,"",""),
                 high = c(2.049,1.653,1.793,1.847,"",""),
                 index = c("red","red","red","black","",""))
dat <- dat %>%
  mutate_at(c('cen','low','high','index'),as.character) %>% 
  mutate_at(c('cen','low','high'),as.numeric)

df <- data.frame(x1 = 1, x2 = 1, y1 = 0, y2 = 0.63)
#options(OutDec = "·")
p3 <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c('','black',"red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.02) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = 'Add days with testing policy index >= 2 (AICc=627.45)', x = 1, y = 0.65,vjust=0,hjust=0.5, fontface = "bold") + #AICc=553·16
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Risk Ratio", y="") + 
  #ylim(0,0.6)+
  scale_y_continuous(expand = c(0.05,0.05))+
  scale_x_log10(limits = c(0.3,3.0), breaks = c(0.5,1.0,2.0))+ ## 
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0,0.5,0), "lines"))+
  theme(legend.position = "none")
p3


## add test quality ######
multi_AIC3 <- within(multi_AIC3,{
  index <- NA
  index[p >= 0.05] <- 'black'
  index[Lower >= 1 & p < 0.05] <- 'red'
  index[Upper <= 1 & p < 0.05] <- 'blue'
})


multi_AIC3$RR
multi_AIC3$Lower
multi_AIC3$Upper
multi_AIC3$index
multi_AIC3$var


dat<- data.frame(group = c(0.55,0.45,0.35,0.25,0.15,0.05),
                 cen = c(1.628,1.300,1.406,"",1.128,""),
                 low = c(1.261,1.024,1.107,"",0.676,""),
                 high = c(2.102,1.649,1.784,"",1.879,""),
                 index = c("red","red","red","", "black",""))
dat <- dat %>%
  mutate_at(c('cen','low','high','index'),as.character) %>% 
  mutate_at(c('cen','low','high'),as.numeric)


p4 <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c('','black',"red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.02) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "Add test data quality (AICc=627.46)", x = 1, y = 0.65,vjust=0,hjust=0.5, fontface = "bold") + #AICc=551·57
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Risk Ratio", y="") + 
 # ylim(0,0.6)+
  scale_y_continuous(expand = c(0.05,0.05))+
  scale_x_log10(limits = c(0.4,3.0), breaks = c(0.5,1.0,2.0))+ ## 
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0,0.5,0), "lines"))+
  theme(legend.position = "none")
p4


## add test per capita ######
multi_AIC4 <- within(multi_AIC4,{
  index <- NA
  index[p >= 0.05] <- 'black'
  index[Lower >= 1 & p < 0.05] <- 'red'
  index[Upper <= 1 & p < 0.05] <- 'blue'
})


multi_AIC4$RR
multi_AIC4$Lower
multi_AIC4$Upper
multi_AIC4$index
multi_AIC4$var

dat<- data.frame(group = c(0.55,0.45,0.35,0.25,0.15,0.05),
                 cen = c(1.722,1.324,1.469,"","", 0.846),
                 low = c(1.306,1.050,1.144,"","", 0.626),
                 high = c(2.271,1.668,1.886,"","", 1.143),
                 index = c("red","red","red","","","black"))
dat <- dat %>%
  mutate_at(c('cen','low','high','index'),as.character) %>% 
  mutate_at(c('cen','low','high'),as.numeric)


p5 <- ggplot(dat,aes(cen,group)) + 
  geom_point(aes(colour = factor(index))) +
  scale_color_manual(values=c('','black',"red"))+
  geom_errorbarh(aes(xmax = high, xmin = low,colour = factor(index)), height = 0.02) +
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), linetype = "longdash",data = df)+
  annotate("text", label = "Add total number of tests per 100K population\nas of 31 Dec. 2020 (AICc=626.50)", x = 1, y = 0.65,vjust=0,hjust=0.5, fontface = "bold") + #AICc=553·23
  #labs(title = "Univariable model") + theme(plot.title = element_text(hjust = 0.25))+
  labs(x="Risk Ratio", y="") + 
  #ylim(0,0.6)+
  scale_y_continuous(expand = c(0.05,0.05))+
  scale_x_log10(limits = c(0.4,3.0), breaks = c(0.5,1.0,2.0))+ ## 
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = unit(c(0.5,0,0.5,0), "lines"))+
  theme(legend.position = "none")
p5

library(gridExtra)

cairo_pdf('./Results/Extended Data/Extended Data Fig. 4 add test.pdf',width=18,height=6) #,family="Arial Unicode MS" 
grid.arrange(data_table,p3,p4,p5, ncol=4, widths = c(2.5,3,3,2.5))
dev.off()



